@echo off
title AI FRAUD SHIELD - Backend ML Server
echo =======================================================
echo    AI FRAUD SHIELD - Backend Machine Learning Server   
echo    Detect Scams. Protect Yourself.                     
echo =======================================================
echo.
cd /d "%~dp0backend"
python app.py
pause
