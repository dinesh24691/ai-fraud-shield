# 🛡️ AI FRAUD SHIELD - Technical Project Report

**Project Title:** AI FRAUD SHIELD: Cyber Social Engineering & Phishing Detection using Machine Learning and Natural Language Processing  
**Tagline:** *Detect Scams. Protect Yourself.*  
**Target Platform:** Android Mobile App (Flutter) + Python ML Engine  
**Objective:** A working software application for College Project Expo and Final Year Engineering Viva.

---

## 1. Executive Summary & Problem Statement

Mobile messaging platforms (SMS, WhatsApp, Telegram) have become the primary attack surface for sophisticated cyber scams in India and worldwide:
- **Utility Bill Extortion:** Threatening power disconnection tonight due to unpaid dues.
- **Banking / KYC Phishing:** Posing as SBI/HDFC/ICICI with deceptive links (`.top`, `.xyz`) to capture PAN card and OTPs.
- **Part-Time Task Scams:** Luring youth with promises of ₹3,000–₹5,000/day for liking YouTube videos.
- **Authority Impersonation:** Fake FedEx/Customs parcel interceptions or digital arrest scams.

Standard spam filters fail because scammers continuously rotate phone numbers and disguise URLs. **AI FRAUD SHIELD** introduces an explainable, multi-factor detection paradigm combining **NLP Machine Learning (TF-IDF + Logistic Regression)** with **structural heuristic threat modeling** to analyze messages, suspicious URLs, and phone numbers in real time.

---

## 2. System Architecture

```mermaid
flowchart TD
    subgraph Client Layer
        A[Android Flutter App] -->|HTTP REST JSON| D[Flask API Gateway]
        B[Interactive Web Dashboard] -->|AJAX Fetch| D
    end

    subgraph Backend Intelligence Layer
        D --> E[NLP Tokenizer & Preprocessor]
        E --> F[TF-IDF Vectorizer Model]
        F --> G[Machine Learning Classifier]
        
        D --> H[Heuristic Signal Engine]
        H --> H1[Urgency Panic Detector]
        H --> H2[Financial & KYC Extortion]
        H --> H3[Authority Impersonation]
        H --> H4[Payload & APK Extraction]
        
        D --> I[Phishing URL Analyzer]
        I --> I1[Typosquatting & IP Host]
        I --> I2[High-Risk TLD & Shortener]
        
        D --> J[Phone Reputation Engine]
        J --> J1[VoIP & Carrier Detection]
        J --> J2[Blacklist Query & Wangiri Check]
    end

    subgraph Decision & XAI Layer
        G & H --> K[Hybrid Risk Blending]
        K --> L[Explainable AI XAI Engine]
        L --> M[SQLite Persistence & Audit Trail]
        L --> N[Output: Risk Level, Probability, Causal Factors, Advice]
    end
```

---

## 3. Core Modules & Implementation Details

### 🏠 Module 1: Home Dashboard
- **Threat Meter Gauge:** Dynamic circular gauge visually communicating overall threat probability.
- **Aggregated Telemetry:** Tracks total scans performed, high-risk items neutralized, suspicious alerts, and verified low-risk messages.
- **Active Fraud Advisories:** Curated live intelligence alerts detailing current scam waves (e.g. Electricity bill extortion, Telegram task scams).
- **Recent Audit Activity:** Live activity list with risk chips and quick navigation.

### 📩 Module 2: SMS & Message Scanner
- Analyzes text for deceptive semantics, urgency timing, and financial requests.
- **Explainable AI (XAI):**
  - **Categorical Risk Badge:** `HIGH RISK` (Crimson), `SUSPICIOUS` (Amber), `LOW RISK` (Emerald).
  - **Fraud Probability Score:** Precise percentage calculated from hybrid model weights.
  - **Risk Factor Breakdown:**
    - Urgency Panic Level (0–100%)
    - Financial / KYC Solicitation (0–100%)
    - Authority Impersonation (0–100%)
    - Link / APK Threat (0–100%)
  - **Extracted Risk Keywords:** Visual warning pills highlighting matched words directly in the text.
  - **Causal Reasons:** Plain-English explanations understandable by ordinary citizens.
  - **Recommended Countermeasures:** Practical safety actions (e.g. "Do not share OTP", "Report to National Cyber Crime portal 1930").

### 🔗 Module 3: Phishing URL Scanner
- **Protocol Inspection:** Unencrypted HTTP vs HTTPS verification.
- **Domain Spoofing & Typosquatting:** Flags unauthorized use of brands (`sbi`, `hdfc`, `amazon`, `paypal`) on foreign hosts.
- **High-Risk TLD Detection:** Evaluates risky free/low-cost extensions (`.top`, `.xyz`, `.click`, `.work`, `.fit`, `.cc`, `.club`).
- **Direct IP Address Detection:** Flags numeric hosts (`http://192.168.1.100/...`).
- **URL Shortener Deobfuscation:** Detects links masked by `bit.ly`, `tinyurl.com`, etc.

### ☎️ Module 4: Phone Number Checker
- **Format Normalization:** Parses international country codes and Indian telecom series.
- **Wangiri Scam Detection:** Flags high-risk international one-ring callback prefixes (`+232`, `+247`, `+252`).
- **VoIP / Virtual Carrier Flags:** Identifies virtual DID numbers commonly utilized by offshore scammers.
- **Cybercrime Blacklist Query:** Returns reported scam category and complaint frequency (e.g. 480+ complaints registered).

### 🤖 Module 5: AI Detection Engine
- **TF-IDF (Term Frequency-Inverse Document Frequency):** Captures 4,000+ n-gram features (unigrams & bigrams) to model scam grammar.
- **Logistic Regression Classifier:** Probabilistic classification with calibrated sigmoid outputs.
- **Rule-Based Blending:** 55% statistical ML + 45% deterministic heuristic safety bounds.
- **Fail-Safe Offline Mode:** Flutter client includes on-device heuristics ensuring the demo functions smoothly even without Wi-Fi.

### 📊 Module 6: Scan History
- Stored persistently in local SQLite (`fraud_shield.db`).
- Supports filtering by type (`all`, `message`, `url`, `phone`), individual record deletion, and complete audit purge.

### ⚙️ Module 7: Settings & Ethical Safeguards
- Visual theme switching: **Cyber Dark Navy** vs **Clean Light Mode**.
- On-device local privacy mode.
- Real-time threat alert toggles.
- Configurable backend server URL (`http://localhost:5050` or LAN IP).
- **Mandatory Safety Disclaimer:** *"AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected."*

---

## 4. Project Expo Viva & Examination Q&A

### Q1: Why did you choose a hybrid model (ML + Heuristics) instead of pure ML?
> **Answer:** "Pure ML models can suffer from false negatives when scammers use novel phrasing or obfuscated characters. By combining TF-IDF classification (for semantic pattern recognition) with deterministic heuristic filters (for high-risk TLDs, known scam phone numbers, and urgency keywords), our system achieves higher resilience and explainability."

### Q2: How does the system explain *why* a message is fraudulent?
> **Answer:** "Our Explainable AI (XAI) engine inspects the activated feature vectors and heuristic trigger matches. It maps linguistic cues into four concrete risk dimensions: Urgency Panic, Financial/KYC Solicitation, Authority Impersonation, and Link/APK Payloads. These are presented in plain language with highlighted keyword tokens."

### Q3: Why doesn't the app label messages as 100% 'SAFE'?
> **Answer:** "In cybersecurity, labeling unknown content as '100% Guaranteed Safe' creates a false sense of security (automation bias). Scammers constantly innovate zero-day social engineering vectors. Therefore, our model cautiously labels unflagged items as 'LOW RISK' and explicitly displays a warning advising users to verify critical transactions through official channels."

---

## 5. Technology Stack Summary

| Layer | Component | Version / Library |
|---|---|---|
| **Frontend Mobile** | Flutter / Dart | Flutter 3.x, Material 3, Provider |
| **Frontend Web** | Responsive HTML5 / CSS3 / ES6 | Vanilla JS, Glassmorphic CSS |
| **Backend API** | Python Flask | Flask 3.1, Flask-CORS, Requests |
| **Machine Learning** | Scikit-Learn | TF-IDF Vectorizer, Logistic Regression |
| **Database** | SQLite 3 | `fraud_shield.db` with relational schema |
