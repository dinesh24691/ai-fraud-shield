@echo off
title Launching AI FRAUD SHIELD Dashboard
echo Launching AI Fraud Shield on http://localhost:5050...
start http://localhost:5050
