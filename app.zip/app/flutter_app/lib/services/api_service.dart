import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/scan_models.dart';

class ApiService {
  // Configurable base URL
  // Default to 10.0.2.2 for Android Emulator, or localhost / LAN IP
  static String baseUrl = 'http://10.0.2.2:5050';

  static void setBaseUrl(String url) {
    baseUrl = url.endsWith('/') ? url.substring(0, url.length - 1) : url;
  }

  // 1. Fetch Dashboard Stats
  static Future<DashboardStats> getDashboardStats() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/stats')).timeout(const Duration(seconds: 4));
      if (response.statusCode == 200) {
        return DashboardStats.fromJson(jsonDecode(response.body));
      }
    } catch (_) {
      // Fallback offline mock for offline expo demonstration
    }
    return DashboardStats(
      totalScanned: 6,
      totalMessages: 3,
      totalUrls: 2,
      totalPhones: 1,
      highRiskCount: 3,
      suspiciousCount: 2,
      lowRiskCount: 1,
      avgRiskScore: 68.0,
      overallStatus: "THREATS BLOCKED",
      shieldColor: "red",
    );
  }

  // 2. Scan SMS / WhatsApp Message
  static Future<MessageScanResult> scanMessage(String message) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/scan/message'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': message}),
      ).timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        return MessageScanResult.fromJson(jsonDecode(response.body));
      }
    } catch (_) {
      // Offline fallback heuristic analyzer
      return _offlineMessageScan(message);
    }
    return _offlineMessageScan(message);
  }

  // 3. Scan URL
  static Future<UrlScanResult> scanUrl(String url) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/scan/url'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'url': url}),
      ).timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        return UrlScanResult.fromJson(jsonDecode(response.body));
      }
    } catch (_) {
      return _offlineUrlScan(url);
    }
    return _offlineUrlScan(url);
  }

  // 4. Check Phone Number
  static Future<PhoneScanResult> scanPhone(String phone) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/scan/phone'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'phone': phone}),
      ).timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        return PhoneScanResult.fromJson(jsonDecode(response.body));
      }
    } catch (_) {
      return _offlinePhoneScan(phone);
    }
    return _offlinePhoneScan(phone);
  }

  // 5. Fetch History
  static Future<List<HistoryItem>> getHistory({String? filter}) async {
    try {
      final url = (filter == null || filter == 'all')
          ? '$baseUrl/api/history'
          : '$baseUrl/api/history?type=$filter';
      final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 4));
      if (response.statusCode == 200) {
        final List list = jsonDecode(response.body);
        return list.map((item) => HistoryItem.fromJson(item)).toList();
      }
    } catch (_) {
      // Return offline sample history items
    }
    return [
      HistoryItem(
        id: 1,
        scanType: 'message',
        inputContent: 'Dear consumer, your electricity power will be disconnected tonight...',
        riskLevel: 'HIGH RISK',
        riskScore: 82.0,
        statusColor: 'red',
        summary: 'Artificial Urgency & Utility Impersonation',
        scanDate: 'Just now',
      ),
      HistoryItem(
        id: 2,
        scanType: 'url',
        inputContent: 'http://sbi-kyc-verify.top/login.php',
        riskLevel: 'HIGH RISK',
        riskScore: 99.0,
        statusColor: 'red',
        summary: 'Brand spoofing SBI on suspicious .top TLD',
        scanDate: '10 mins ago',
      ),
      HistoryItem(
        id: 3,
        scanType: 'phone',
        inputContent: '+91 98234 12345',
        riskLevel: 'HIGH RISK',
        riskScore: 96.0,
        statusColor: 'red',
        summary: 'Reported 480+ times for electricity extortion',
        scanDate: '1 hour ago',
      )
    ];
  }

  // 6. Delete History
  static Future<bool> deleteHistoryItem(int id) async {
    try {
      final res = await http.delete(Uri.parse('$baseUrl/api/history/$id'));
      return res.statusCode == 200;
    } catch (_) {
      return true;
    }
  }

  // 7. Clear All History
  static Future<bool> clearHistory() async {
    try {
      final res = await http.delete(Uri.parse('$baseUrl/api/history'));
      return res.statusCode == 200;
    } catch (_) {
      return true;
    }
  }

  // --- Offline Fallback Heuristics ---
  static MessageScanResult _offlineMessageScan(String msg) {
    final lower = msg.toLowerCase();
    bool isUrgent = lower.contains('tonight') || lower.contains('immediately') || lower.contains('within 24') || lower.contains('blocked');
    bool isMoney = lower.contains('kyc') || lower.contains('pan') || lower.contains('bill') || lower.contains('upi') || lower.contains('rs');
    bool isAuthority = lower.contains('sbi') || lower.contains('hdfc') || lower.contains('power') || lower.contains('electricity') || lower.contains('officer');

    double score = 15.0;
    List<String> reasons = [];
    List<String> keywords = [];

    if (isUrgent) { score += 35; reasons.add("Urgency cues detected creating artificial panic."); keywords.add("urgency"); }
    if (isMoney) { score += 30; reasons.add("Financial or KYC credential solicitation detected."); keywords.add("financial"); }
    if (isAuthority) { score += 25; reasons.add("Authority or utility impersonation identified."); keywords.add("impersonation"); }

    String level = score >= 70 ? "HIGH RISK" : (score >= 35 ? "SUSPICIOUS" : "LOW RISK");
    return MessageScanResult(
      riskLevel: level,
      riskScore: score,
      statusColor: score >= 70 ? "red" : (score >= 35 ? "orange" : "green"),
      modelConfidence: 85.0,
      reasons: reasons.isEmpty ? ["No prominent scam vocabulary detected."] : reasons,
      matchedKeywords: keywords,
      riskBreakdown: {
        "urgency_level": isUrgent ? 80 : 10,
        "financial_threat": isMoney ? 75 : 10,
        "impersonation_threat": isAuthority ? 70 : 10,
        "link_threat": lower.contains('http') ? 85 : 0
      },
      recommendations: [
        "Do NOT share OTPs, PINs, or confidential banking information.",
        "Verify all communications through official registered bank channels."
      ],
      disclaimer: "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected.",
    );
  }

  static UrlScanResult _offlineUrlScan(String url) {
    final lower = url.toLowerCase();
    bool isTop = lower.contains('.top') || lower.contains('.xyz') || lower.contains('.club');
    bool isHttp = lower.startsWith('http://');
    bool isBrand = lower.contains('sbi') || lower.contains('hdfc') || lower.contains('bank');

    double score = 15.0;
    List<String> flags = [];
    if (isHttp) { score += 20; flags.add("Insecure protocol: HTTP without encryption."); }
    if (isTop) { score += 40; flags.add("High-risk TLD frequently abused in phishing campaigns."); }
    if (isBrand) { score += 35; flags.add("Brand name appearing on third-party non-official domain."); }

    return UrlScanResult(
      url: url,
      hostname: Uri.tryParse(url)?.host ?? url,
      riskLevel: score >= 70 ? "HIGH RISK" : (score >= 35 ? "SUSPICIOUS" : "LOW RISK"),
      riskScore: score,
      statusColor: score >= 70 ? "red" : "orange",
      flags: flags.isEmpty ? ["Standard domain format observed."] : flags,
      recommendations: ["Always check browser padlock certificate and official domain name."],
      disclaimer: "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected.",
    );
  }

  static PhoneScanResult _offlinePhoneScan(String phone) {
    bool isReported = phone.contains('9823412345') || phone.contains('9876543210');
    return PhoneScanResult(
      phoneNumber: phone,
      cleanNumber: phone,
      riskLevel: isReported ? "HIGH RISK" : "LOW RISK",
      riskScore: isReported ? 96.0 : 10.0,
      statusColor: isReported ? "red" : "green",
      category: isReported ? "Utility Extortion / KYC Fraud" : "Standard Mobile",
      carrierType: "Cellular",
      location: "India",
      reportsCount: isReported ? 482 : 0,
      flags: isReported ? ["Blacklisted in cybercrime complaint database."] : ["Standard carrier format."],
      warnings: isReported ? ["Do not accept payment requests or transfer funds."] : ["Standard caution recommended."],
      disclaimer: "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected.",
    );
  }
}
