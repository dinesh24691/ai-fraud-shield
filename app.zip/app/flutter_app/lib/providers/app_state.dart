import 'package:flutter/material.dart';
import '../models/scan_models.dart';
import '../services/api_service.dart';

class AppState extends ChangeNotifier {
  bool _isDarkMode = true;
  int _selectedTab = 0;
  bool _isLoading = false;
  DashboardStats _stats = DashboardStats.empty();
  List<HistoryItem> _history = [];

  bool get isDarkMode => _isDarkMode;
  int get selectedTab => _selectedTab;
  bool get isLoading => _isLoading;
  DashboardStats get stats => _stats;
  List<HistoryItem> get history => _history;

  AppState() {
    loadInitialData();
  }

  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  void setTab(int index) {
    _selectedTab = index;
    notifyListeners();
    if (index == 0) loadStats();
    if (index == 4) loadHistory();
  }

  Future<void> loadInitialData() async {
    _isLoading = true;
    notifyListeners();
    await Future.wait([loadStats(), loadHistory()]);
    _isLoading = false;
    notifyListeners();
  }

  Future<void> loadStats() async {
    _stats = await ApiService.getDashboardStats();
    notifyListeners();
  }

  Future<void> loadHistory({String? filter}) async {
    _history = await ApiService.getHistory(filter: filter);
    notifyListeners();
  }

  Future<void> deleteHistoryItem(int id) async {
    await ApiService.deleteHistoryItem(id);
    _history.removeWhere((item) => item.id == id);
    loadStats();
    notifyListeners();
  }

  Future<void> clearHistory() async {
    await ApiService.clearHistory();
    _history.clear();
    loadStats();
    notifyListeners();
  }
}
