import 'package:flutter/material.dart';
import '../models/scan_models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class PhoneScannerScreen extends StatefulWidget {
  const PhoneScannerScreen({Key? key}) : super(key: key);

  @override
  State<PhoneScannerScreen> createState() => _PhoneScannerScreenState();
}

class _PhoneScannerScreenState extends State<PhoneScannerScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _isLoading = false;
  PhoneScanResult? _result;

  final List<Map<String, String>> _phonePresets = [
    {'title': '⚡ Electricity Extortionist (480+ reports)', 'phone': '9823412345'},
    {'title': '🎰 KBC Lottery Fraud', 'phone': '9876543210'},
    {'title': '🌍 Wangiri Scam (+232)', 'phone': '+23276123456'},
    {'title': '✅ Official SBI Care', 'phone': '1800112211'},
  ];

  Future<void> _checkPhone() async {
    final phone = _controller.text.trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a phone number.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final res = await ApiService.scanPhone(phone);
      setState(() => _result = res);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Phone Check error: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Text('☎️', style: TextStyle(fontSize: 22)),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Phone Number Reputation Checker',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Cross-references community cybercrime blacklist, VoIP carrier ranges, and high-risk international numbers.',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 14),

                const Text('⚡ Expo Demo Presets:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.neonCyan)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _phonePresets.map((preset) {
                    return ActionChip(
                      backgroundColor: AppColors.surfaceLight,
                      label: Text(preset['title']!, style: const TextStyle(fontSize: 11, color: Colors.white)),
                      onPressed: () {
                        setState(() {
                          _controller.text = preset['phone']!;
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),

                TextField(
                  controller: _controller,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(fontSize: 13, color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'Enter phone number (e.g. 9823412345 or +91 98234 12345)',
                  ),
                ),
                const SizedBox(height: 14),

                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isLoading ? null : _checkPhone,
                        icon: _isLoading
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF041226)))
                            : const Icon(Icons.security_outlined),
                        label: Text(_isLoading ? 'Checking Database...' : 'Check Reputation'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () {
                        _controller.clear();
                        setState(() => _result = null);
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cardBorder),
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Clear', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),

          if (_result != null) _buildResultCard(_result!),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildResultCard(PhoneScanResult res) {
    Color riskColor = res.riskLevel == 'HIGH RISK'
        ? AppColors.dangerRed
        : (res.riskLevel == 'SUSPICIOUS' ? AppColors.warningOrange : AppColors.neonGreen);

    return GlassCard(
      borderColor: riskColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: riskColor.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: riskColor, width: 1.5),
                ),
                child: Text(
                  res.riskLevel,
                  style: TextStyle(color: riskColor, fontWeight: FontWeight.w800, fontSize: 13),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '${res.riskScore.round()}%',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  const Text('Fraud Score', style: TextStyle(fontSize: 10, color: AppColors.textDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Classification: ${res.category}',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white),
          ),
          const SizedBox(height: 14),

          // Details grid
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Column(
              children: [
                _buildInfoRow('Location', res.location),
                const Divider(color: Colors.white12, height: 16),
                _buildInfoRow('Network Carrier', res.carrierType),
                const Divider(color: Colors.white12, height: 16),
                _buildInfoRow(
                  'Cyber Complaints',
                  '${res.reportsCount} Reports',
                  valueColor: res.reportsCount > 0 ? AppColors.dangerRed : AppColors.neonGreen,
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),

          const Text('Reputation Findings:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 6),
          Column(
            children: res.flags.map((flag) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(color: AppColors.neonCyan, fontWeight: FontWeight.bold)),
                    Expanded(child: Text(flag, style: const TextStyle(fontSize: 11.5, color: Colors.white70, height: 1.3))),
                  ],
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 14),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.neonCyan.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('🛡️ Warnings & Action:', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.neonCyan)),
                const SizedBox(height: 6),
                Column(
                  children: res.warnings.map((w) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.warning_amber_rounded, size: 14, color: AppColors.warningOrange),
                          const SizedBox(width: 6),
                          Expanded(child: Text(w, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.warningOrange.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.warningOrange.withOpacity(0.3)),
            ),
            child: Text(
              res.disclaimer,
              style: const TextStyle(fontSize: 10.5, color: Color(0xFFFDE68A), height: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {Color? valueColor}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
        Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: valueColor ?? AppColors.neonCyan)),
      ],
    );
  }
}
