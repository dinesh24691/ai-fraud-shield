import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _privacyMode = true;
  bool _notifications = true;

  void _showApiConfigDialog(BuildContext context) {
    final textController = TextEditingController(text: ApiService.baseUrl);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Backend API Server', style: TextStyle(color: Colors.white, fontSize: 16)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Enter the backend URL (use 10.0.2.2:5050 for Android Emulator, or your PC Wi-Fi IP for physical phone):',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: textController,
              style: const TextStyle(fontSize: 13, color: Colors.white),
              decoration: const InputDecoration(hintText: 'http://192.168.1.x:5050'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white)),
          ),
          ElevatedButton(
            onPressed: () {
              ApiService.setBaseUrl(textController.text.trim());
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('API Server updated to: ${ApiService.baseUrl}')),
              );
              setState(() {});
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Settings & Preferences',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white),
          ),
          const SizedBox(height: 14),

          // Toggles Card
          GlassCard(
            child: Column(
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: AppColors.neonCyan,
                  title: const Text('Dark Cyber Theme', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)),
                  subtitle: const Text('Futuristic dark navy palette with neon glowing accents', style: TextStyle(fontSize: 11, color: AppColors.textDim)),
                  value: state.isDarkMode,
                  onChanged: (val) => state.toggleTheme(),
                ),
                const Divider(color: Colors.white12),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: AppColors.neonCyan,
                  title: const Text('On-Device Privacy', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)),
                  subtitle: const Text('Store analyzed text history locally without cloud transmission', style: TextStyle(fontSize: 11, color: AppColors.textDim)),
                  value: _privacyMode,
                  onChanged: (val) => setState(() => _privacyMode = val),
                ),
                const Divider(color: Colors.white12),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  activeColor: AppColors.neonCyan,
                  title: const Text('Threat Alerts Notification', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)),
                  subtitle: const Text('Receive immediate alert upon scanning critical threats', style: TextStyle(fontSize: 11, color: AppColors.textDim)),
                  value: _notifications,
                  onChanged: (val) => setState(() => _notifications = val),
                ),
                const Divider(color: Colors.white12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Backend API Server', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white)),
                  subtitle: Text(ApiService.baseUrl, style: const TextStyle(fontSize: 11, color: AppColors.neonCyan)),
                  trailing: const Icon(Icons.edit_outlined, color: AppColors.neonCyan, size: 18),
                  onTap: () => _showApiConfigDialog(context),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // About Card
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.shield_outlined, color: AppColors.neonCyan, size: 22),
                    SizedBox(width: 8),
                    Text(
                      'About AI FRAUD SHIELD',
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  'AI Fraud Shield is an intelligent cyber fraud detection application designed to protect smartphone users from social engineering, phishing, and scam messages.',
                  style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary, height: 1.4),
                ),
                const SizedBox(height: 14),

                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.04),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [
                      _buildInfoRow('Project Purpose', 'College Project Expo Demo'),
                      const Divider(color: Colors.white12, height: 14),
                      _buildInfoRow('Technology Stack', 'Flutter + Python + ML'),
                      const Divider(color: Colors.white12, height: 14),
                      _buildInfoRow('Target OS', 'Android'),
                      const Divider(color: Colors.white12, height: 14),
                      _buildInfoRow('Model Engine', 'TF-IDF + Heuristic XAI'),
                      const Divider(color: Colors.white12, height: 14),
                      _buildInfoRow('Version', '2.0.0 (Expo Edition)'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Mandatory Advisory
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppColors.warningOrange.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.warningOrange.withOpacity(0.3)),
                  ),
                  child: const Text(
                    'Important Safety Notice: AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected. Report suspicious cyber crimes to 1930.',
                    style: TextStyle(fontSize: 10.5, color: Color(0xFFFDE68A), height: 1.3),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        Text(value, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.neonCyan)),
      ],
    );
  }
}
