import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';
import '../widgets/risk_gauge.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    final stats = state.stats;

    return RefreshIndicator(
      onRefresh: () => state.loadStats(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Hero Threat Status Card
            GlassCard(
              borderColor: stats.avgRiskScore >= 60 ? AppColors.dangerRed : AppColors.neonCyan,
              child: Column(
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      RiskGauge(score: stats.avgRiskScore, size: 120),
                      const SizedBox(width: 18),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: (stats.shieldColor == 'red' ? AppColors.dangerRed : AppColors.neonGreen).withOpacity(0.15),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: stats.shieldColor == 'red' ? AppColors.dangerRed : AppColors.neonGreen,
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                stats.overallStatus,
                                style: TextStyle(
                                  color: stats.shieldColor == 'red' ? AppColors.dangerRed : AppColors.neonGreen,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'AI Cyber Defense',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Real-time NLP social engineering detection active.',
                              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => state.setTab(1),
                          icon: const Icon(Icons.bolt, size: 18),
                          label: const Text('Scan SMS'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => state.setTab(2),
                          icon: const Icon(Icons.link, size: 18, color: AppColors.neonCyan),
                          label: const Text('Check Link', style: TextStyle(color: Colors.white)),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: AppColors.cardBorder),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),

            // 2. Metrics Grid
            Row(
              children: [
                _buildMetricTile('Total Scans', '${stats.totalScanned}', Icons.analytics_outlined, AppColors.neonCyan),
                const SizedBox(width: 10),
                _buildMetricTile('High Risk', '${stats.highRiskCount}', Icons.dangerous_outlined, AppColors.dangerRed),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                _buildMetricTile('Suspicious', '${stats.suspiciousCount}', Icons.warning_amber_rounded, AppColors.warningOrange),
                const SizedBox(width: 10),
                _buildMetricTile('Verified Low', '${stats.lowRiskCount}', Icons.verified_user_outlined, AppColors.neonGreen),
              ],
            ),

            const SizedBox(height: 16),

            // 2.5 Threat Analytics Bar Chart Card
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: const [
                          Icon(Icons.bar_chart_rounded, color: AppColors.neonCyan, size: 22),
                          SizedBox(width: 8),
                          Text(
                            'Threat Severity Bar Chart',
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: AppColors.neonCyan.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.neonCyan.withOpacity(0.3)),
                        ),
                        child: const Text('ANALYTICS', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, color: AppColors.neonCyan)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Horizontal Colored Bar Charts
                  _buildThreatBar(
                    label: '🚨 High Risk Threats Blocked',
                    count: stats.highRiskCount,
                    total: stats.totalScanned,
                    color: AppColors.dangerRed,
                  ),
                  const SizedBox(height: 10),
                  _buildThreatBar(
                    label: '⚠️ Suspicious Alerts Flagged',
                    count: stats.suspiciousCount,
                    total: stats.totalScanned,
                    color: AppColors.warningOrange,
                  ),
                  const SizedBox(height: 10),
                  _buildThreatBar(
                    label: '🛡️ Low Risk Verified Items',
                    count: stats.lowRiskCount,
                    total: stats.totalScanned,
                    color: AppColors.neonGreen,
                  ),
                  const SizedBox(height: 10),
                  _buildThreatBar(
                    label: '⚡ Detection Accuracy',
                    count: 98,
                    total: 100,
                    color: AppColors.neonCyan,
                    isPercentage: true,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // 3. Active Threat Advisories
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Active Threat Advisories',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.dangerRed.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.dangerRed.withOpacity(0.4)),
                  ),
                  child: const Text('LIVE ALERTS', style: TextStyle(fontSize: 10, color: Color(0xFFFCA5A5), fontWeight: FontWeight.bold)),
                ),
              ],
            ),
            const SizedBox(height: 12),

            _buildThreatItem(
              title: 'Electricity Power Cut Extortion Scam',
              desc: 'SMS threatening power disconnection tonight unless bill is updated. Never call unverified officer numbers.',
              severity: 'CRITICAL',
              color: AppColors.dangerRed,
            ),
            _buildThreatItem(
              title: 'SBI / HDFC KYC Expiry Phishing',
              desc: 'Phishing URLs with .top or .xyz asking victims to enter PAN card or install remote control APK.',
              severity: 'HIGH',
              color: AppColors.warningOrange,
            ),
            _buildThreatItem(
              title: 'Part-Time Rating / Telegram Task Scam',
              desc: 'Promises Rs 3,000-5,000/day for liking videos. Steals security deposits and personal info.',
              severity: 'MODERATE',
              color: AppColors.neonBlue,
            ),

            const SizedBox(height: 16),

            // 4. Mandatory Expo Disclaimer
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.warningOrange.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.warningOrange.withOpacity(0.3)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Icon(Icons.warning_rounded, color: AppColors.warningOrange, size: 22),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'College Project Expo Notice: AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected. Verify all critical alerts via official channels.',
                      style: TextStyle(fontSize: 11.5, color: Color(0xFFFDE68A), height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricTile(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.surface.withOpacity(0.85),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.cardBorder),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white)),
                Text(label, style: const TextStyle(fontSize: 10.5, color: AppColors.textDim)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThreatItem({required String title, required String desc, required String severity, required Color color}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border(left: BorderSide(color: color, width: 4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white)),
              Text(severity, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: color)),
            ],
          ),
          const SizedBox(height: 4),
          Text(desc, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary, height: 1.3)),
        ],
      ),
    );
  }

  Widget _buildThreatBar({
    required String label,
    required int count,
    required int total,
    required Color color,
    bool isPercentage = false,
  }) {
    final effectiveTotal = total > 0 ? total : 1;
    final double pct = isPercentage ? (count / 100.0) : (count / effectiveTotal).clamp(0.05, 1.0);
    final String displayVal = isPercentage ? '$count%' : '${(pct * 100).round()}% ($count)';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
            Text(displayVal, style: TextStyle(fontSize: 11.5, color: color, fontWeight: FontWeight.w700)),
          ],
        ),
        const SizedBox(height: 5),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: pct,
            backgroundColor: Colors.white.withOpacity(0.06),
            valueColor: AlwaysStoppedAnimation<Color>(color),
            minHeight: 8,
          ),
        ),
      ],
    );
  }
}
