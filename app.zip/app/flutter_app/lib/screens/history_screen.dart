import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _selectedFilter = 'all';

  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    final history = state.history;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with Clear Button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Scan History Log',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
                  Text(
                    'Audit trail of evaluated messages & links',
                    style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary),
                  ),
                ],
              ),
              TextButton.icon(
                onPressed: history.isEmpty ? null : () => _confirmClear(context, state),
                icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.dangerRed, size: 18),
                label: const Text('Clear All', style: TextStyle(color: AppColors.dangerRed, fontSize: 12)),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Filter chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip('all', 'All Scans', state),
                const SizedBox(width: 8),
                _buildFilterChip('message', '📩 Messages', state),
                const SizedBox(width: 8),
                _buildFilterChip('url', '🔗 URLs', state),
                const SizedBox(width: 8),
                _buildFilterChip('phone', '☎️ Phones', state),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // History list
          if (history.isEmpty)
            GlassCard(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24),
                  child: Column(
                    children: const [
                      Icon(Icons.history_outlined, size: 40, color: AppColors.textDim),
                      SizedBox(height: 8),
                      Text('No scan history recorded yet.', style: TextStyle(color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ),
            )
          else
            Column(
              children: history.map((item) {
                Color riskColor = item.riskLevel == 'HIGH RISK'
                    ? AppColors.dangerRed
                    : (item.riskLevel == 'SUSPICIOUS' ? AppColors.warningOrange : AppColors.neonGreen);

                IconData typeIcon = item.scanType == 'url'
                    ? Icons.link
                    : (item.scanType == 'phone' ? Icons.phone_android : Icons.message);

                return GlassCard(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(typeIcon, color: riskColor, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: riskColor.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: riskColor.withOpacity(0.4)),
                                  ),
                                  child: Text(
                                    '${item.riskLevel} (${item.riskScore.round()}%)',
                                    style: TextStyle(color: riskColor, fontSize: 10.5, fontWeight: FontWeight.bold),
                                  ),
                                ),
                                Text(
                                  item.scanDate,
                                  style: const TextStyle(fontSize: 10, color: AppColors.textDim),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              item.inputContent,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.white),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item.summary,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close, size: 16, color: AppColors.textDim),
                        onPressed: () => state.deleteHistoryItem(item.id),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String key, String label, AppState state) {
    bool isSelected = _selectedFilter == key;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      selectedColor: AppColors.neonCyan.withOpacity(0.25),
      backgroundColor: AppColors.surfaceLight,
      labelStyle: TextStyle(
        fontSize: 11.5,
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        color: isSelected ? AppColors.neonCyan : Colors.white70,
      ),
      side: BorderSide(
        color: isSelected ? AppColors.neonCyan : Colors.transparent,
      ),
      onSelected: (selected) {
        if (selected) {
          setState(() => _selectedFilter = key);
          state.loadHistory(filter: key);
        }
      },
    );
  }

  void _confirmClear(BuildContext context, AppState state) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Clear Scan History?'),
        content: const Text('This will permanently delete all saved scan history items.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: Colors.white)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.dangerRed),
            onPressed: () {
              Navigator.pop(ctx);
              state.clearHistory();
            },
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }
}
