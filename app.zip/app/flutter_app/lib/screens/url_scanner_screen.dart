import 'package:flutter/material.dart';
import '../models/scan_models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class UrlScannerScreen extends StatefulWidget {
  const UrlScannerScreen({Key? key}) : super(key: key);

  @override
  State<UrlScannerScreen> createState() => _UrlScannerScreenState();
}

class _UrlScannerScreenState extends State<UrlScannerScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _isLoading = false;
  UrlScanResult? _result;

  final List<Map<String, String>> _urlPresets = [
    {'title': '🛑 Fake SBI Portal', 'url': 'http://sbi-kyc-verify.top/login.php'},
    {'title': '📦 Prize Shortener', 'url': 'https://bit.ly/amazon-gift-winner-2026'},
    {'title': '🌐 Direct IP Host', 'url': 'http://192.168.1.105/bank-security'},
    {'title': '✅ Official SBI URL', 'url': 'https://www.onlinesbi.sbi'},
  ];

  Future<void> _scanUrl() async {
    final url = _controller.text.trim();
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a website link to evaluate.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final res = await ApiService.scanUrl(url);
      setState(() => _result = res);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('URL Scan error: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Text('🔗', style: TextStyle(fontSize: 22)),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Phishing URL & Domain Scanner',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Checks for typosquatting, high-risk TLDs (.top, .xyz), IP addresses, and brand impersonation.',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 14),

                const Text('⚡ Expo Demo Presets:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.neonCyan)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _urlPresets.map((preset) {
                    return ActionChip(
                      backgroundColor: AppColors.surfaceLight,
                      label: Text(preset['title']!, style: const TextStyle(fontSize: 11, color: Colors.white)),
                      onPressed: () {
                        setState(() {
                          _controller.text = preset['url']!;
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),

                TextField(
                  controller: _controller,
                  style: const TextStyle(fontSize: 13, color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'Enter link (e.g. http://sbi-kyc-verify.top)',
                  ),
                ),
                const SizedBox(height: 14),

                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isLoading ? null : _scanUrl,
                        icon: _isLoading
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF041226)))
                            : const Icon(Icons.search),
                        label: Text(_isLoading ? 'Inspecting Host...' : 'Analyze URL Safety'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () {
                        _controller.clear();
                        setState(() => _result = null);
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cardBorder),
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Clear', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),

          if (_result != null) _buildResultCard(_result!),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildResultCard(UrlScanResult res) {
    Color riskColor = res.riskLevel == 'HIGH RISK'
        ? AppColors.dangerRed
        : (res.riskLevel == 'SUSPICIOUS' ? AppColors.warningOrange : AppColors.neonGreen);

    return GlassCard(
      borderColor: riskColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: riskColor.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: riskColor, width: 1.5),
                ),
                child: Text(
                  res.riskLevel,
                  style: TextStyle(color: riskColor, fontWeight: FontWeight.w800, fontSize: 13),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '${res.riskScore.round()}%',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  const Text('Phishing Risk', style: TextStyle(fontSize: 10, color: AppColors.textDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Target Host: ${res.hostname}',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.neonCyan),
          ),
          const SizedBox(height: 14),

          const Text('Inspection Flags:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 6),
          Column(
            children: res.flags.map((flag) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(color: AppColors.neonCyan, fontWeight: FontWeight.bold)),
                    Expanded(child: Text(flag, style: const TextStyle(fontSize: 11.5, color: Colors.white70, height: 1.3))),
                  ],
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 14),

          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.neonCyan.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('🛡️ Safety Recommendations:', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.neonCyan)),
                const SizedBox(height: 6),
                Column(
                  children: res.recommendations.map((rec) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.check_circle_outline, size: 14, color: AppColors.neonCyan),
                          const SizedBox(width: 6),
                          Expanded(child: Text(rec, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.warningOrange.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.warningOrange.withOpacity(0.3)),
            ),
            child: Text(
              res.disclaimer,
              style: const TextStyle(fontSize: 10.5, color: Color(0xFFFDE68A), height: 1.3),
            ),
          ),
        ],
      ),
    );
  }
}
