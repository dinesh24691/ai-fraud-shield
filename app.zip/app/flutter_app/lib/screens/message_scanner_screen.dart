import 'package:flutter/material.dart';
import '../models/scan_models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/glass_card.dart';

class MessageScannerScreen extends StatefulWidget {
  const MessageScannerScreen({Key? key}) : super(key: key);

  @override
  State<MessageScannerScreen> createState() => _MessageScannerScreenState();
}

class _MessageScannerScreenState extends State<MessageScannerScreen> {
  final TextEditingController _controller = TextEditingController();
  bool _isLoading = false;
  MessageScanResult? _result;

  final List<Map<String, String>> _demoPresets = [
    {
      'title': '⚡ Electricity Scam',
      'text': 'Dear consumer, your electricity power will be disconnected tonight at 9.30 PM from power office because your previous month bill was not updated. Please immediately contact our electricity officer at 9823412345.'
    },
    {
      'title': '🏦 SBI KYC Phishing',
      'text': 'Dear SBI user, your account will be blocked today due to pending KYC. Click http://sbi-kyc-verify.top to update your PAN immediately.'
    },
    {
      'title': '💼 Part-Time Job Scam',
      'text': 'Congratulations! You are selected for part time job. Work 1 hour daily from home by rating Google maps and earn Rs 3000 to 5000 daily. Contact HR Priya on WhatsApp: http://wa.me/919988112233'
    },
    {
      'title': '✅ Safe Bank SMS',
      'text': 'Your SBI account XX4092 is credited with Rs 5,000.00 on 08-Oct-26 by transfer from John Doe. Available balance is Rs 45,210.00.'
    }
  ];

  Future<void> _analyzeMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please paste or enter a message to scan.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _result = null;
    });

    try {
      final res = await ApiService.scanMessage(text);
      setState(() {
        _result = res;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Analysis error: $e')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Input Card
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Text('📩', style: TextStyle(fontSize: 22)),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'SMS & WhatsApp Message Scanner',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  'Paste any suspicious message to evaluate cyber fraud risk using Machine Learning NLP.',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 14),

                // Fast Expo Demo Presets
                const Text('⚡ Expo Demo Presets:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: AppColors.neonCyan)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _demoPresets.map((preset) {
                    return ActionChip(
                      backgroundColor: AppColors.surfaceLight,
                      label: Text(preset['title']!, style: const TextStyle(fontSize: 11, color: Colors.white)),
                      onPressed: () {
                        setState(() {
                          _controller.text = preset['text']!;
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),

                // Text field
                TextField(
                  controller: _controller,
                  maxLines: 4,
                  style: const TextStyle(fontSize: 13, color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'Paste SMS, WhatsApp text, or notification here...',
                  ),
                ),
                const SizedBox(height: 14),

                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isLoading ? null : _analyzeMessage,
                        icon: _isLoading
                            ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF041226)))
                            : const Icon(Icons.psychology_outlined),
                        label: Text(_isLoading ? 'Analyzing with NLP...' : 'Scan with AI'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () {
                        _controller.clear();
                        setState(() => _result = null);
                      },
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.cardBorder),
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Clear', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Analysis Results Card
          if (_result != null) _buildResultCard(_result!),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildResultCard(MessageScanResult res) {
    Color riskColor;
    if (res.riskLevel == 'HIGH RISK') {
      riskColor = AppColors.dangerRed;
    } else if (res.riskLevel == 'SUSPICIOUS') {
      riskColor = AppColors.warningOrange;
    } else {
      riskColor = AppColors.neonGreen;
    }

    final breakdown = res.riskBreakdown;

    return GlassCard(
      borderColor: riskColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner with Score
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: riskColor.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: riskColor, width: 1.5),
                ),
                child: Text(
                  res.riskLevel,
                  style: TextStyle(color: riskColor, fontWeight: FontWeight.w800, fontSize: 13, letterSpacing: 0.5),
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '${res.riskScore.round()}%',
                    style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white),
                  ),
                  const SizedBox(width: 4),
                  const Text('Fraud Probability', style: TextStyle(fontSize: 10, color: AppColors.textDim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Sub-factor bars
          _buildFactorBar('Urgency Panic Level', (breakdown['urgency_level'] ?? 0).toDouble()),
          _buildFactorBar('Financial / KYC Solicitation', (breakdown['financial_threat'] ?? 0).toDouble()),
          _buildFactorBar('Authority Impersonation', (breakdown['impersonation_threat'] ?? 0).toDouble()),
          _buildFactorBar('Link / APK Payload Threat', (breakdown['link_threat'] ?? 0).toDouble()),

          const SizedBox(height: 14),

          // Matched keywords
          if (res.matchedKeywords.isNotEmpty) ...[
            const Text('Flagged Risk Keywords:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: res.matchedKeywords.map((kw) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.dangerRed.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.dangerRed.withOpacity(0.4)),
                  ),
                  child: Text('⚠️ $kw', style: const TextStyle(fontSize: 11, color: Color(0xFFFCA5A5), fontWeight: FontWeight.w600)),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
          ],

          // Plain-English Reasons
          const Text('AI Detection Reasons:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 6),
          Column(
            children: res.reasons.map((reason) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• ', style: TextStyle(color: AppColors.neonCyan, fontWeight: FontWeight.bold)),
                    Expanded(child: Text(reason, style: const TextStyle(fontSize: 11.5, color: Colors.white70, height: 1.3))),
                  ],
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 14),

          // Safety Recommendations
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.neonCyan.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.neonCyan.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('🛡️ Safety Recommendations:', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: AppColors.neonCyan)),
                const SizedBox(height: 6),
                Column(
                  children: res.recommendations.map((rec) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.check_circle_outline, size: 14, color: AppColors.neonCyan),
                          const SizedBox(width: 6),
                          Expanded(child: Text(rec, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary))),
                        ],
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Mandatory Disclaimer
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.warningOrange.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.warningOrange.withOpacity(0.3)),
            ),
            child: Text(
              res.disclaimer,
              style: const TextStyle(fontSize: 10.5, color: Color(0xFFFDE68A), height: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFactorBar(String title, double value) {
    Color barColor = value >= 60 ? AppColors.dangerRed : (value >= 35 ? AppColors.warningOrange : AppColors.neonCyan);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              Text('${value.round()}%', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: barColor)),
            ],
          ),
          const SizedBox(height: 3),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: (value / 100).clamp(0.0, 1.0),
              backgroundColor: Colors.white.withOpacity(0.06),
              valueColor: AlwaysStoppedAnimation<Color>(barColor),
              minHeight: 5,
            ),
          ),
        ],
      ),
    );
  }
}
