class MessageScanResult {
  final int? id;
  final String riskLevel;
  final double riskScore;
  final String statusColor;
  final double modelConfidence;
  final List<String> reasons;
  final List<String> matchedKeywords;
  final Map<String, dynamic> riskBreakdown;
  final List<String> recommendations;
  final String disclaimer;

  MessageScanResult({
    this.id,
    required this.riskLevel,
    required this.riskScore,
    required this.statusColor,
    required this.modelConfidence,
    required this.reasons,
    required this.matchedKeywords,
    required this.riskBreakdown,
    required this.recommendations,
    required this.disclaimer,
  });

  factory MessageScanResult.fromJson(Map<String, dynamic> json) {
    return MessageScanResult(
      id: json['id'],
      riskLevel: json['risk_level'] ?? 'UNKNOWN',
      riskScore: (json['risk_score'] as num?)?.toDouble() ?? 0.0,
      statusColor: json['status_color'] ?? 'cyan',
      modelConfidence: (json['model_confidence'] as num?)?.toDouble() ?? 0.0,
      reasons: List<String>.from(json['reasons'] ?? []),
      matchedKeywords: List<String>.from(json['matched_keywords'] ?? []),
      riskBreakdown: json['risk_breakdown'] ?? {},
      recommendations: List<String>.from(json['recommendations'] ?? []),
      disclaimer: json['disclaimer'] ?? '',
    );
  }
}

class UrlScanResult {
  final int? id;
  final String url;
  final String hostname;
  final String riskLevel;
  final double riskScore;
  final String statusColor;
  final List<String> flags;
  final List<String> recommendations;
  final String disclaimer;

  UrlScanResult({
    this.id,
    required this.url,
    required this.hostname,
    required this.riskLevel,
    required this.riskScore,
    required this.statusColor,
    required this.flags,
    required this.recommendations,
    required this.disclaimer,
  });

  factory UrlScanResult.fromJson(Map<String, dynamic> json) {
    return UrlScanResult(
      id: json['id'],
      url: json['url'] ?? '',
      hostname: json['hostname'] ?? '',
      riskLevel: json['risk_level'] ?? 'UNKNOWN',
      riskScore: (json['risk_score'] as num?)?.toDouble() ?? 0.0,
      statusColor: json['status_color'] ?? 'cyan',
      flags: List<String>.from(json['flags'] ?? []),
      recommendations: List<String>.from(json['recommendations'] ?? []),
      disclaimer: json['disclaimer'] ?? '',
    );
  }
}

class PhoneScanResult {
  final int? id;
  final String phoneNumber;
  final String cleanNumber;
  final String riskLevel;
  final double riskScore;
  final String statusColor;
  final String category;
  final String carrierType;
  final String location;
  final int reportsCount;
  final List<String> flags;
  final List<String> warnings;
  final String disclaimer;

  PhoneScanResult({
    this.id,
    required this.phoneNumber,
    required this.cleanNumber,
    required this.riskLevel,
    required this.riskScore,
    required this.statusColor,
    required this.category,
    required this.carrierType,
    required this.location,
    required this.reportsCount,
    required this.flags,
    required this.warnings,
    required this.disclaimer,
  });

  factory PhoneScanResult.fromJson(Map<String, dynamic> json) {
    return PhoneScanResult(
      id: json['id'],
      phoneNumber: json['phone_number'] ?? '',
      cleanNumber: json['clean_number'] ?? '',
      riskLevel: json['risk_level'] ?? 'UNKNOWN',
      riskScore: (json['risk_score'] as num?)?.toDouble() ?? 0.0,
      statusColor: json['status_color'] ?? 'cyan',
      category: json['category'] ?? 'Mobile',
      carrierType: json['carrier_type'] ?? 'Cellular',
      location: json['location'] ?? 'Unknown',
      reportsCount: json['reports_count'] ?? 0,
      flags: List<String>.from(json['flags'] ?? []),
      warnings: List<String>.from(json['warnings'] ?? []),
      disclaimer: json['disclaimer'] ?? '',
    );
  }
}

class HistoryItem {
  final int id;
  final String scanType;
  final String inputContent;
  final String riskLevel;
  final double riskScore;
  final String statusColor;
  final String summary;
  final String scanDate;

  HistoryItem({
    required this.id,
    required this.scanType,
    required this.inputContent,
    required this.riskLevel,
    required this.riskScore,
    required this.statusColor,
    required this.summary,
    required this.scanDate,
  });

  factory HistoryItem.fromJson(Map<String, dynamic> json) {
    return HistoryItem(
      id: json['id'] ?? 0,
      scanType: json['scan_type'] ?? 'message',
      inputContent: json['input_content'] ?? '',
      riskLevel: json['risk_level'] ?? 'LOW RISK',
      riskScore: (json['risk_score'] as num?)?.toDouble() ?? 0.0,
      statusColor: json['status_color'] ?? 'green',
      summary: json['summary'] ?? '',
      scanDate: json['scan_date'] ?? '',
    );
  }
}

class DashboardStats {
  final int totalScanned;
  final int totalMessages;
  final int totalUrls;
  final int totalPhones;
  final int highRiskCount;
  final int suspiciousCount;
  final int lowRiskCount;
  final double avgRiskScore;
  final String overallStatus;
  final String shieldColor;

  DashboardStats({
    required this.totalScanned,
    required this.totalMessages,
    required this.totalUrls,
    required this.totalPhones,
    required this.highRiskCount,
    required this.suspiciousCount,
    required this.lowRiskCount,
    required this.avgRiskScore,
    required this.overallStatus,
    required this.shieldColor,
  });

  factory DashboardStats.empty() {
    return DashboardStats(
      totalScanned: 0,
      totalMessages: 0,
      totalUrls: 0,
      totalPhones: 0,
      highRiskCount: 0,
      suspiciousCount: 0,
      lowRiskCount: 0,
      avgRiskScore: 0.0,
      overallStatus: "PROTECTED",
      shieldColor: "cyan",
    );
  }

  factory DashboardStats.fromJson(Map<String, dynamic> json) {
    return DashboardStats(
      totalScanned: json['total_scanned'] ?? 0,
      totalMessages: json['total_messages'] ?? 0,
      totalUrls: json['total_urls'] ?? 0,
      totalPhones: json['total_phones'] ?? 0,
      highRiskCount: json['high_risk_count'] ?? 0,
      suspiciousCount: json['suspicious_count'] ?? 0,
      lowRiskCount: json['low_risk_count'] ?? 0,
      avgRiskScore: (json['avg_risk_score'] as num?)?.toDouble() ?? 0.0,
      overallStatus: json['overall_status'] ?? 'PROTECTED',
      shieldColor: json['shield_color'] ?? 'cyan',
    );
  }
}
