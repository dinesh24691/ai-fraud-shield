@echo off
title AI FRAUD SHIELD - Deploy & Share Online
echo =======================================================
echo    AI FRAUD SHIELD - Public Online Deployment Runner   
echo    Detect Scams. Protect Yourself.                     
echo =======================================================
echo.
echo [1/2] Starting Backend Server on port 5050...
start /b python backend\app.py

echo [2/2] Launching Cloudflare Public Secure Tunnel...
echo.
echo Tunnel is generating a live public HTTPS link...
echo You can open this link on your Android / iPhone and share with friends!
echo.
.\cloudflared.exe tunnel --url http://localhost:5050
pause
