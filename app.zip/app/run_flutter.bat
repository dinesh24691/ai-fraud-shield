@echo off
title AI FRAUD SHIELD - Flutter Android App
echo =======================================================
echo    AI FRAUD SHIELD - Flutter Android App Runner        
echo =======================================================
echo.
cd /d "%~dp0flutter_app"
flutter run
pause
