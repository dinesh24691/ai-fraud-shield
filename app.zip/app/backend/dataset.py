"""
AI Fraud Shield - Training Dataset
Contains labeled SMS/messages for training the Fraud and Spam Detection Machine Learning Model.
Includes modern fraud scenarios: Banking KYC, Electricity disconnection,
Job task scams, Customs/Parcel fraud, Lottery/KBC, and legitimate messages.
"""

TRAINING_DATA = [
    # --- HIGH RISK / FRAUD / PHISHING EXAMPLES ---
    # Banking / KYC Scam
    ("Dear SBI user, your account will be blocked today due to pending KYC. Click http://sbi-kyc-verify.top to update your PAN immediately.", 1),
    ("Alert: Your HDFC Bank debit card is deactivated. To reactivate immediately, submit details at http://hdfc-card-renew.xyz or call 9876543210", 1),
    ("Dear customer, your ICICI bank account is suspended. Click link http://icici-verify-login.cc to update Aadhaar immediately to avoid penalty.", 1),
    ("Axis Bank alert: Your account has been temporarily locked. Verify your credentials at http://axis-online-secure.work/login immediately.", 1),
    ("Important notice: Your Kotak account will be frozen within 24 hours. Update KYC now at http://kotak-kyc-desk.top to continue services.", 1),
    ("Bank alert: Unauthorized transaction of Rs 48,999 detected on your card. If not done by you, immediately cancel at http://cancel-txn-bank.xyz", 1),
    ("Dear customer, your credit card reward points worth Rs 9,850 are expiring tonight. Redeem cash instantly to your bank account at http://reward-redeem-bank.click", 1),
    ("Urgent: Your PNB account is under review for suspicious transactions. Download APK and verify: http://pnb-security-update.club", 1),

    # Electricity / Utility Bill Scams
    ("Dear consumer, your electricity power will be disconnected tonight at 9.30 PM from power office because your previous month bill was not updated. Please immediately contact our electricity officer at 9823412345.", 1),
    ("Urgent notice: Electricity bill payment of Rs. 3,450 pending. Power will be disconnected in 2 hours. Call power manager 8765432109 immediately.", 1),
    ("Bescom alert: Your power supply will be cut off tonight at 8 PM due to unpaid bill. Pay immediately using link http://bescom-pay-bill.online", 1),
    ("MSEDCL: Your electricity will be disconnected tonight. Update bill instantly or call electric department official 9988776655.", 1),
    ("Water department notice: Your water supply will be suspended tomorrow due to meter fee arrears. Clear bill now at http://water-bill-clear.xyz", 1),

    # Part-time Job / Telegram Task Scams
    ("Congratulations! You are selected for part time job. Work 1 hour daily from home by rating Google maps and earn Rs 3000 to 5000 daily. Contact HR Priya on WhatsApp: http://wa.me/919988112233", 1),
    ("Amazon HR hiring! Work from home part time. Daily salary 2500 - 8000 Rs directly credited to UPI. No experience needed. Join Telegram @amazon_job_india", 1),
    ("YouTube video like and subscribe job! Earn Rs 150 per like. Earn up to Rs 6000 per day. Payment via Google Pay. Contact our manager on Telegram @daily_task_earning", 1),
    ("Earn passive income online. Hotel review writing job. Earn Rs 4000 daily. Just 30 minutes daily. Click to join our recruitment team: http://earn-money-daily.top", 1),
    ("Part-time data entry job. Earn Rs 500 per page. Instant daily payout. Registration fee only Rs 500 refundable. Contact on WhatsApp 918877665544.", 1),

    # Lottery / Kaun Banega Crorepati (KBC) / Prize Scams
    ("Dear Jio customer, your mobile number has won Rs 25,00,000 in KBC Jio Lucky Draw 2026. To claim your prize money contact Mr. Rana Pratap Singh on WhatsApp 9876543210.", 1),
    ("Congratulations! You have won an Apple iPhone 16 Pro in Amazon Lucky Spin. Pay Rs 499 courier fee to dispatch your gift. Claim at http://amazon-prize-winner.xyz", 1),
    ("You are the lucky winner of Coca Cola international lottery worth $500,000 USD. Send your bank details and passport copy to claimprize@cocacola-draw.top", 1),
    ("Dear user, you have been selected for Rs 10 Lakh car loan with 0% interest and Rs 50,000 cash bonus. Click http://quick-cash-loan.top to get funds in 5 minutes.", 1),
    ("Your phone number won 1st prize in Dubai shopping festival draw. Contact claim agent on WhatsApp +971501234567 to receive funds.", 1),

    # Courier / Parcel / Customs Scams
    ("FedEx Delivery Alert: Your parcel #IN88921 cannot be delivered due to incorrect delivery address and unpaid customs tax of Rs 149. Update address at http://fedex-parcel-tracking.xyz", 1),
    ("India Post alert: Your package is on hold at Mumbai sorting hub due to missing postal details. Confirm address within 12 hours: http://indiapost-parcel-update.top", 1),
    ("DHL Express: Parcel with narcotics and illegal passport registered under your Aadhaar has been intercepted at airport. Connect to Delhi Police officer immediately.", 1),
    ("BlueDart courier: Package failed delivery. Update address and pay re-delivery charge Rs 25 here: http://bluedart-track-delivery.click", 1),

    # Government / Tax / Subsidy Scams
    ("Income Tax Notice: Your income tax refund of Rs 18,740 has been approved. Provide bank account details and debit card info to receive refund: http://incometax-refund-gov.xyz", 1),
    ("PM Kisan Yojana: Next installment of Rs 6,000 will be credited. Verify your Aadhaar card and OTP at http://pmkisan-scheme-verify.top immediately.", 1),
    ("EPFO alert: Your provident fund balance of Rs 1,45,000 has been sanctioned for release. Submit bank passbook copy and OTP to transfer funds.", 1),
    ("Ministry of Finance notice: Claim your free solar panel subsidy grant of Rs 50,000. Apply now at http://free-solar-subsidy.club before deadline.", 1),

    # SIM Card / Telecom Scams
    ("Airtel urgent: Your SIM card will be deactivated within 24 hours due to non-verification of KYC. Call customer officer 9811223344 or update at http://airtel-kyc-portal.top", 1),
    ("Vi alert: Your SIM card documents are invalid. Service will stop tonight. Send OTP received on your phone to continue calling.", 1),
    ("BSNL notice: 5G upgrade completed. To activate high speed internet, dial *401*9876543210# and confirm. Avoid SIM suspension.", 1),

    # Crypto / Investment / Ponzi Scams
    ("Guaranteed 200% returns in 7 days! Invest in our crypto trading AI bot. Minimum investment Rs 5000 gives Rs 15000 profit. Join Telegram @crypto_wealth_official", 1),
    ("Stock market insider tips! 100% accurate intraday calls. Make Rs 50,000 daily with zero risk. Click to join VIP WhatsApp group: http://stock-market-tips.top", 1),
    ("Bitcoin investment opportunity. Our algorithm trades for you with guaranteed 15% daily profit. Withdraw anytime to your UPI.", 1),

    # Credential & OTP Phishing
    ("Security Alert: Someone tried to sign into your Google account from Russia. If this was not you, verify your password immediately at http://google-security-auth.top", 1),
    ("Instagram notification: Your account will be deleted in 24 hours for copyright violation. Appeal here: http://instagram-appeal-center.xyz", 1),
    ("Netflix membership: Your billing payment failed. Your subscription will be cancelled today. Update payment method: http://netflix-payment-update.top", 1),
    ("Dear user, verify your WhatsApp account to prevent ban. Reply with the 6-digit registration code sent to your phone immediately.", 1),

    # --- LEGITIMATE / HAM EXAMPLES ---
    # Transactional & Genuine Alerts
    ("Your SBI account XX4092 is credited with Rs 5,000.00 on 08-Oct-26 by transfer from John Doe. Available balance is Rs 45,210.00.", 0),
    ("Dear HDFC Bank customer, Rs 450.00 was spent on your card ending 1204 at Starbucks on 09-Oct-26. Info: SMS NOTPAY if not you.", 0),
    ("Your One Time Password (OTP) for login to ICICI NetBanking is 591024. Valid for 10 minutes. Do not share your OTP with anyone, including bank staff.", 0),
    ("Axis Bank: Your OTP for transaction of Rs 1,299.00 at Swiggy is 847291. Bank never asks for OTP or CVV over call or message.", 0),
    ("Your Amazon order #402-8921829 has been dispatched and will arrive tomorrow by 8 PM. Track your package in the Amazon app.", 0),
    ("Hi Rahul, Flipkart delivery agent is out for delivery with your package. Share PIN 4821 with the agent upon delivery.", 0),
    ("Dear customer, your Airtel fiber broadband bill for October of Rs 943 is due on 15-Oct-26. Pay easily via Airtel Thanks app.", 0),
    ("Your Uber ride OTP is 3921. Driver Ramesh (Swift Dzire KA03AB1234) is arriving in 3 mins.", 0),
    ("IRCTC ticket confirmation: PNR 4829104829, Train 12628 Karnataka Express, Coach B2, Seat 45, Confirmed. Happy Journey!", 0),
    ("Dear user, your Swiggy order from Domino's Pizza has been picked up by delivery partner. Arriving in 15 mins.", 0),
    ("Zomato: Your order from Chai Point is delivered. Hope you enjoyed the food! Rate your experience in the app.", 0),
    ("Your doctor appointment with Dr. Mehta at Apollo Hospital is scheduled for tomorrow at 11:30 AM. Please arrive 15 minutes early.", 0),
    ("Your Google verification code is 492019. It will expire in 5 minutes.", 0),
    ("Microsoft account security code: 829104. Use this to verify your identity.", 0),
    ("Dear Student, your semester examination hall ticket has been released. Download from the college portal www.university.edu.in.", 0),

    # Casual / Personal Messages
    ("Hey Meghana! Are we still meeting for lunch at 1 PM today? Let me know.", 0),
    ("Can you please share the project presentation slides when you get a chance? Thanks!", 0),
    ("Mom called, she said dinner will be ready by 8:30 PM. Don't be late.", 0),
    ("Happy birthday dear! Wishing you lots of happiness, success and good health in the year ahead!", 0),
    ("Hey guys, the professor shifted tomorrow's machine learning class to Thursday morning 10 AM.", 0),
    ("I have reached the metro station. Where are you standing?", 0),
    ("Please check your email, I have forwarded the research paper for our literature survey.", 0),
    ("Thanks for the help yesterday with the coding assignment! Really appreciate it.", 0),
    ("The lab records need to be submitted by Monday 4 PM to the HOD office.", 0),
    ("Are you coming to the college project expo tomorrow? Our stall number is B-14.", 0),
    ("Great presentation today! The external examiner was very impressed with your demo.", 0),
    ("Let's connect on Zoom tonight at 8 PM to finalize the final project report.", 0),
    ("Call me once you are free, need to discuss something important about the project viva.", 0),
    ("Good morning! Remember to bring the college ID card and project synopsis copy today.", 0)
]
