"""
URL Security & Phishing Analyzer
Inspects website URLs for phishing signatures, domain spoofing, typosquatting,
suspicious TLDs, IP addresses, URL shorteners, and deceptive path patterns.
"""

import re
from urllib.parse import urlparse

HIGH_RISK_TLDS = {
    "xyz", "top", "click", "work", "fit", "gq", "tk", "ml", "cf", "ga",
    "cc", "club", "buzz", "rest", "icu", "link", "monster", "quest", "cyou", "vip"
}

KNOWN_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd", "rb.gy",
    "ow.ly", "rebrand.ly", "buff.ly", "goo.gl"
}

TARGETED_BRANDS = [
    "sbi", "hdfc", "icici", "axis", "kotak", "pnb", "paytm", "phonepe",
    "googlepay", "paypal", "amazon", "flipkart", "netflix", "apple",
    "microsoft", "google", "facebook", "instagram", "whatsapp", "telegram",
    "binance", "coinbase", "incometax", "uidai", "irctc"
]

PHISHING_KEYWORDS = [
    "login", "signin", "verify", "verification", "update", "kyc", "secure",
    "security", "account", "banking", "wallet", "recover", "claim", "prize",
    "refund", "bonus", "reward", "password", "credential", "auth", "billing"
]

IP_PATTERN = re.compile(r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$")


def analyze_url(raw_url: str) -> dict:
    """
    Evaluates URL security risk.
    Returns composite score, risk level, flagged indicators, and recommendations.
    """
    url = raw_url.strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        # Normalize protocol for parsing
        test_url = "http://" + url
    else:
        test_url = url

    try:
        parsed = urlparse(test_url)
    except Exception:
        return {
            "url": raw_url,
            "risk_level": "SUSPICIOUS",
            "risk_score": 60.0,
            "status_color": "orange",
            "flags": ["Malformed or unparseable URL structure"],
            "indicators": {},
            "recommendations": ["Do not open malformed or suspicious links."],
            "disclaimer": "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected."
        }

    hostname = (parsed.hostname or "").lower()
    path = (parsed.path or "").lower()
    query = (parsed.query or "").lower()
    full_str = test_url.lower()

    flags = []
    risk_score = 5.0  # Base caution score

    indicators = {
        "is_https": parsed.scheme == "https",
        "has_ip_hostname": False,
        "is_shortener": False,
        "suspicious_tld": False,
        "brand_spoofing": False,
        "phishing_keywords": [],
        "excessive_subdomains": False,
        "has_at_symbol": False
    }

    # 1. Scheme Check
    if parsed.scheme == "http":
        flags.append("Insecure Protocol: Uses unencrypted HTTP rather than HTTPS.")
        risk_score += 15.0

    # 2. IP Hostname Check
    if IP_PATTERN.match(hostname):
        indicators["has_ip_hostname"] = True
        flags.append("Direct IP Host: Uses numeric IP address instead of domain name, a classic phishing tactic.")
        risk_score += 45.0

    # 3. URL Shortener Check
    if hostname in KNOWN_SHORTENERS:
        indicators["is_shortener"] = True
        flags.append("URL Shortener Detected: Masks the real destination server (e.g. bit.ly, tinyurl).")
        risk_score += 25.0

    # 4. TLD Check
    parts = hostname.split(".")
    tld = parts[-1] if len(parts) > 1 else ""
    if tld in HIGH_RISK_TLDS:
        indicators["suspicious_tld"] = True
        flags.append(f"High-Risk TLD (.{tld}): Free or cheap domain extensions frequently abused in cyber attacks.")
        risk_score += 30.0

    # 5. Brand Impersonation / Typosquatting in Hostname
    matched_brands = []
    for brand in TARGETED_BRANDS:
        if brand in hostname:
            # Check if domain is legitimate official domain
            official_domains = [f"{brand}.com", f"{brand}.co.in", f"{brand}.in", f"{brand}.org", f"{brand}.net"]
            is_legit = any(hostname == od or hostname.endswith("." + od) for od in official_domains)
            if not is_legit:
                matched_brands.append(brand)

    if matched_brands:
        indicators["brand_spoofing"] = True
        flags.append(f"Brand Impersonation / Squatting: Contains '{', '.join(matched_brands)}' on an unverified third-party host.")
        risk_score += 45.0

    # 6. Phishing Keywords in Path or Query
    matched_keywords = []
    for kw in PHISHING_KEYWORDS:
        if kw in path or kw in query or (kw in hostname and not indicators["brand_spoofing"]):
            matched_keywords.append(kw)

    if matched_keywords:
        indicators["phishing_keywords"] = matched_keywords[:4]
        flags.append(f"Phishing Triggers: Found sensitive keywords ({', '.join(matched_keywords[:3])}) in the URL.")
        risk_score += min(30.0, len(matched_keywords) * 10.0)

    # 7. Subdomains Depth & Hyphens
    subdomain_count = max(0, len(parts) - 2)
    if subdomain_count >= 3:
        indicators["excessive_subdomains"] = True
        flags.append("Excessive Subdomains: Multiple nested subdomains often disguise the true top-level root.")
        risk_score += 20.0

    if hostname.count("-") >= 2:
        flags.append("Deceptive Hyphens: Multiple hyphens used to mimic legitimate corporate domain names.")
        risk_score += 15.0

    # 8. Hidden '@' redirect trick
    if "@" in raw_url:
        indicators["has_at_symbol"] = True
        flags.append("Authentication '@' Obfuscation: Uses '@' symbol to trick users regarding the actual host.")
        risk_score += 40.0

    # Cap score
    risk_score = round(min(99.0, max(5.0, risk_score)), 1)

    if risk_score >= 70.0:
        risk_level = "HIGH RISK"
        status_color = "red"
    elif risk_score >= 35.0:
        risk_level = "SUSPICIOUS"
        status_color = "orange"
    else:
        risk_level = "LOW RISK"
        status_color = "green"

    # Actionable recommendations
    recommendations = []
    if risk_level == "HIGH RISK":
        recommendations.append("Do NOT open this website or input any credentials or personal info.")
        recommendations.append("The domain shows multiple characteristics of fraudulent phishing infrastructure.")
    elif risk_level == "SUSPICIOUS":
        recommendations.append("Exercise extreme caution. Inspect the domain carefully before proceeding.")
        recommendations.append("Do not enter credit card numbers, passwords, or banking details.")
    else:
        recommendations.append("No obvious phishing patterns identified, but always verify domain authenticity.")
        recommendations.append("Ensure the browser padlock displays a valid SSL certificate for the intended organization.")

    if not flags:
        flags.append("Standard domain structure and expected formatting observed.")

    return {
        "url": raw_url,
        "hostname": hostname,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "status_color": status_color,
        "flags": flags,
        "indicators": indicators,
        "recommendations": recommendations,
        "disclaimer": "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected."
    }


if __name__ == "__main__":
    test_urls = [
        "http://sbi-kyc-verify.top/login.php",
        "https://bit.ly/claim-amazon-prize",
        "https://www.google.com/search?q=cybersecurity"
    ]
    for u in test_urls:
        print(f"\n--- Testing: {u} ---")
        res = analyze_url(u)
        print(f"Risk: {res['risk_level']} ({res['risk_score']}%) | Flags: {res['flags']}")
