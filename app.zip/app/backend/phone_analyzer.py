"""
Phone Number Reputation & Risk Checker
Evaluates suspicious phone numbers, parses international country codes,
detects VoIP/virtual carrier patterns, checks against known fraud intelligence databases,
and computes a spam risk score with actionable warnings.
"""

import re

# High-risk international calling prefixes known for Wangiri / Missed-call scams
HIGH_RISK_COUNTRY_CODES = {
    "+232": "Sierra Leone (Frequently abused in Wangiri one-ring scams)",
    "+247": "Ascension Island (Known for toll-fraud premium rate callbacks)",
    "+252": "Somalia (High incidence of international missed-call frauds)",
    "+216": "Tunisia (Common Wangiri scam origin)",
    "+223": "Mali (High spam callback abuse)",
    "+882": "International Networks / Satellite (Very high per-minute charges)"
}

# Known scam/fraud patterns and reported numbers for college demo showcase
KNOWN_FRAUD_DATABASE = {
    "9823412345": {
        "spam_score": 96,
        "reports_count": 482,
        "category": "Utility Bill Scam",
        "description": "Reported 480+ times for posing as electricity board officer threatening power disconnection.",
        "risk_level": "HIGH RISK"
    },
    "9876543210": {
        "spam_score": 98,
        "reports_count": 1240,
        "category": "Lottery & Bank KYC Fraud",
        "description": "Flagged as fraudulent caller impersonating SBI customer care and KBC lottery manager.",
        "risk_level": "HIGH RISK"
    },
    "8765432109": {
        "spam_score": 92,
        "reports_count": 310,
        "category": "Electricity / Power Fraud",
        "description": "Reported across multiple states for fake bill arrears extortion.",
        "risk_level": "HIGH RISK"
    },
    "9988112233": {
        "spam_score": 89,
        "reports_count": 275,
        "category": "Telegram Task / Job Scam",
        "description": "WhatsApp contact associated with fraudulent part-time YouTube like rating scams.",
        "risk_level": "HIGH RISK"
    },
    "9811223344": {
        "spam_score": 88,
        "reports_count": 194,
        "category": "SIM KYC Deactivation Scam",
        "description": "Threatens victims with SIM deactivation and requests remote access APK download.",
        "risk_level": "HIGH RISK"
    },
    "1800112211": {
        "spam_score": 4,
        "reports_count": 0,
        "category": "Verified Toll-Free Bank Line",
        "description": "Official State Bank of India Customer Care Toll-Free Line.",
        "risk_level": "LOW RISK"
    }
}


def analyze_phone_number(raw_phone: str) -> dict:
    """
    Analyzes phone number for fraud, spam reputation, virtual carrier markers,
    and formats.
    """
    clean_digits = re.sub(r"[^\d+]", "", raw_phone.strip())
    # Extract only numbers for local matching
    digits_only = re.sub(r"\D", "", clean_digits)

    flags = []
    warnings = []
    risk_score = 10.0  # Base line caution
    category = "Standard Mobile"
    carrier_type = "Cellular"
    location = "India"
    reports_count = 0

    # 1. Check known fraud registry
    matched_db = None
    # Check full digits or last 10 digits
    last_10 = digits_only[-10:] if len(digits_only) >= 10 else digits_only
    if last_10 in KNOWN_FRAUD_DATABASE:
        matched_db = KNOWN_FRAUD_DATABASE[last_10]
    elif digits_only in KNOWN_FRAUD_DATABASE:
        matched_db = KNOWN_FRAUD_DATABASE[digits_only]

    if matched_db:
        risk_score = matched_db["spam_score"]
        reports_count = matched_db["reports_count"]
        category = matched_db["category"]
        flags.append(f"Flagged in Cybercrime Blacklist: {matched_db['description']}")
        warnings.append(f"High community alert: {reports_count} fraud complaints registered against this number.")
    else:
        # Heuristic checks
        # 2. International high-risk origin checks
        for code, info in HIGH_RISK_COUNTRY_CODES.items():
            if clean_digits.startswith(code):
                risk_score += 65.0
                flags.append(f"International High-Risk Calling Code: {info}")
                warnings.append("Never call back unknown missed calls from unfamiliar international country codes.")
                category = "International Toll Scam"
                location = info.split("(")[0].strip()

        # 3. Format & series checks
        if clean_digits.startswith("+1"):
            location = "United States / Canada"
            # Check US VoIP prefixes
            if len(digits_only) == 11 and digits_only[1:4] in ["415", "929", "833", "844", "855"]:
                carrier_type = "VoIP / Virtual Number (Twilio/Google Voice)"
                flags.append("Virtual DID / VoIP carrier detected. Commonly used by offshore callers to spoof presence.")
                risk_score += 25.0
        elif clean_digits.startswith("+44"):
            location = "United Kingdom"
        elif len(digits_only) == 10:
            location = "India"
            first_digit = digits_only[0]
            if first_digit in ["6", "7", "8", "9"]:
                carrier_type = "Indian Mobile Subscriber (GSM/LTE)"
            else:
                flags.append("Unusual Indian number series: Mobile numbers in India start with 6, 7, 8, or 9.")
                risk_score += 30.0
        elif len(digits_only) == 11 and digits_only.startswith("0"):
            location = "India (STD Landline)"
            carrier_type = "Fixed Landline"
        elif clean_digits.startswith("1800"):
            category = "Toll-Free Helpline"
            carrier_type = "Toll-Free"
            risk_score = 5.0
        elif len(digits_only) < 10:
            flags.append("Irregular short phone number. May be an internal IVR, shortcode, or incomplete number.")
            risk_score += 20.0

        # Spoofing heuristics (repeated digits like 9999999999, 1234567890)
        if len(set(digits_only)) <= 3 and len(digits_only) >= 8:
            flags.append("Suspicious repeated-digit pattern. Likely a spoofed caller ID.")
            risk_score += 35.0

    risk_score = round(min(99.0, max(5.0, risk_score)), 1)

    if risk_score >= 70.0:
        risk_level = "HIGH RISK"
        status_color = "red"
        warnings.append("Do NOT share any bank OTP, personal information, or transfer money to this caller.")
    elif risk_score >= 35.0:
        risk_level = "SUSPICIOUS"
        status_color = "orange"
        warnings.append("Caller reputation contains unverified or suspicious characteristics.")
    else:
        risk_level = "LOW RISK"
        status_color = "green"
        warnings.append("No active scam reports found in database. Exercise standard caution with unknown callers.")

    if not flags:
        flags.append("Standard carrier routing format. No prior fraud reports recorded.")

    return {
        "phone_number": raw_phone,
        "clean_number": clean_digits,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "status_color": status_color,
        "category": category,
        "carrier_type": carrier_type,
        "location": location,
        "reports_count": reports_count,
        "flags": flags,
        "warnings": warnings,
        "disclaimer": "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected."
    }


if __name__ == "__main__":
    test_nums = ["9823412345", "+23212345678", "9988776655", "1800112211"]
    for n in test_nums:
        print(f"\n--- Testing: {n} ---")
        res = analyze_phone_number(n)
        print(f"Risk: {res['risk_level']} ({res['risk_score']}%) | Category: {res['category']} | Flags: {res['flags']}")
