"""
AI Fraud Shield - SQLite Database Manager
Handles scan history persistence, dashboard metrics calculation,
and history clearing/deletion operations.
"""

import sqlite3
import json
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "fraud_shield.db")


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS scan_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_type TEXT NOT NULL,          -- 'message', 'url', 'phone'
            input_content TEXT NOT NULL,
            risk_level TEXT NOT NULL,          -- 'HIGH RISK', 'SUSPICIOUS', 'LOW RISK'
            risk_score REAL NOT NULL,
            status_color TEXT NOT NULL,
            summary TEXT,
            details_json TEXT,
            scan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()

    # Prepopulate with a couple realistic demo history items if database is freshly created
    cursor.execute("SELECT COUNT(*) FROM scan_history")
    count = cursor.fetchone()[0]
    if count == 0:
        demo_items = [
            (
                "message",
                "Dear consumer, your electricity power will be disconnected tonight at 9.30 PM from power office...",
                "HIGH RISK",
                82.0,
                "red",
                "Urgent power disconnection threat with fake officer number",
                json.dumps({
                    "urgency_score": 70,
                    "matched_keywords": ["tonight", "disconnected", "power office"],
                    "category": "Utility Bill Fraud"
                })
            ),
            (
                "url",
                "http://sbi-kyc-verify.top/login.php",
                "HIGH RISK",
                95.0,
                "red",
                "Phishing domain impersonating SBI with suspicious .top TLD",
                json.dumps({
                    "brand": "sbi",
                    "tld": "top",
                    "insecure_http": True
                })
            ),
            (
                "phone",
                "+91 98234 12345",
                "HIGH RISK",
                96.0,
                "red",
                "Blacklisted in 480+ complaints posing as electricity officer",
                json.dumps({
                    "reports": 482,
                    "category": "Utility Bill Scam"
                })
            ),
            (
                "message",
                "Your Amazon order #402-8921829 has been dispatched and will arrive tomorrow by 8 PM.",
                "LOW RISK",
                12.0,
                "green",
                "Legitimate e-commerce tracking notification",
                json.dumps({
                    "category": "Transactional"
                })
            )
        ]
        cursor.executemany("""
            INSERT INTO scan_history (scan_type, input_content, risk_level, risk_score, status_color, summary, details_json)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, demo_items)
        conn.commit()
    conn.close()


def save_scan_record(scan_type: str, input_content: str, risk_level: str, risk_score: float, status_color: str, summary: str, details: dict) -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO scan_history (scan_type, input_content, risk_level, risk_score, status_color, summary, details_json, scan_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        scan_type,
        input_content,
        risk_level,
        risk_score,
        status_color,
        summary,
        json.dumps(details),
        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ))
    record_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return record_id


def get_all_history(scan_type: str = None, limit: int = 50) -> list:
    conn = get_db_connection()
    cursor = conn.cursor()
    if scan_type and scan_type.lower() != 'all':
        cursor.execute("""
            SELECT * FROM scan_history
            WHERE scan_type = ?
            ORDER BY id DESC LIMIT ?
        """, (scan_type.lower(), limit))
    else:
        cursor.execute("""
            SELECT * FROM scan_history
            ORDER BY id DESC LIMIT ?
        """, (limit,))
    rows = cursor.fetchall()
    results = []
    for row in rows:
        item = dict(row)
        try:
            item["details"] = json.loads(item["details_json"]) if item["details_json"] else {}
        except Exception:
            item["details"] = {}
        results.append(item)
    conn.close()
    return results


def delete_history_item(item_id: int) -> bool:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM scan_history WHERE id = ?", (item_id,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted


def clear_all_history() -> int:
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM scan_history")
    count = cursor.rowcount
    conn.commit()
    conn.close()
    return count


def get_dashboard_stats() -> dict:
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM scan_history")
    total_scanned = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE scan_type = 'message'")
    total_messages = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE scan_type = 'url'")
    total_urls = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE scan_type = 'phone'")
    total_phones = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE risk_level = 'HIGH RISK'")
    high_risk_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE risk_level = 'SUSPICIOUS'")
    suspicious_count = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM scan_history WHERE risk_level = 'LOW RISK'")
    low_risk_count = cursor.fetchone()[0]

    cursor.execute("SELECT AVG(risk_score) FROM scan_history")
    avg_score_row = cursor.fetchone()[0]
    avg_score = round(float(avg_score_row), 1) if avg_score_row else 0.0

    conn.close()

    # Determine overall security threat status
    if total_scanned == 0:
        overall_status = "READY"
        shield_color = "cyan"
    elif high_risk_count > 0:
        overall_status = "THREATS BLOCKED"
        shield_color = "red"
    elif suspicious_count > 0:
        overall_status = "ATTENTION REQUIRED"
        shield_color = "orange"
    else:
        overall_status = "PROTECTED"
        shield_color = "green"

    return {
        "total_scanned": total_scanned,
        "total_messages": total_messages,
        "total_urls": total_urls,
        "total_phones": total_phones,
        "high_risk_count": high_risk_count,
        "suspicious_count": suspicious_count,
        "low_risk_count": low_risk_count,
        "avg_risk_score": avg_score,
        "overall_status": overall_status,
        "shield_color": shield_color
    }


# Initialize DB on load
init_db()
