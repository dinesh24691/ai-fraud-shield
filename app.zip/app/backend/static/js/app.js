// AI FRAUD SHIELD - Core Frontend Logic

let sampleMessages = [];

// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  loadStats();
  loadRecentActivity();
  loadSamples();
  setupTheme();
});

// Tab Switching
function initTabs() {
  const navButtons = document.querySelectorAll('.nav-item');
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });
}

function switchTab(tabId) {
  // Update desktop & mobile horizontal pill nav buttons
  document.querySelectorAll('.nav-item').forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
      // Scroll horizontal nav-bar so active item is centered on mobile
      btn.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    } else {
      btn.classList.remove('active');
    }
  });

  // Update mobile bottom dock buttons
  document.querySelectorAll('.mobile-nav-btn').forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Update drawer nav items
  document.querySelectorAll('.drawer-nav-item').forEach(btn => {
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  // Update tab panes
  document.querySelectorAll('.tab-pane').forEach(pane => {
    if (pane.id === tabId) {
      pane.classList.add('active');
    } else {
      pane.classList.remove('active');
    }
  });

  // Scroll to top smoothly
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Refresh data if history or home
  if (tabId === 'tab-history') {
    loadHistory();
  } else if (tabId === 'tab-home') {
    loadStats();
    loadRecentActivity();
  }
}

// Mobile Slide-Out Drawer Controls
function toggleMobileDrawer() {
  const drawer = document.getElementById('mobileDrawer');
  if (drawer) {
    drawer.classList.toggle('active');
  }
}

function closeMobileDrawer(e) {
  const drawer = document.getElementById('mobileDrawer');
  if (drawer) {
    drawer.classList.remove('active');
  }
}

function navFromDrawer(tabId) {
  switchTab(tabId);
  closeMobileDrawer();
}

// Share Website Functionality (Web Share API + Clipboard Toast)
async function shareWebsite() {
  const shareData = {
    title: 'AI FRAUD SHIELD',
    text: '🛡️ Check out AI Fraud Shield - Detect cyber scams, fake SMS, and phishing links in real time!',
    url: window.location.href
  };

  if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
    try {
      await navigator.share(shareData);
      return;
    } catch (err) {
      if (err.name !== 'AbortError') console.error('Share failed:', err);
    }
  }

  // Fallback to Clipboard Copy
  try {
    await navigator.clipboard.writeText(window.location.href);
    showToast('🔗 Website link copied to clipboard!');
  } catch (err) {
    prompt('Copy this website link to share:', window.location.href);
  }
}

function showToast(msg) {
  const toast = document.getElementById('toastNotification');
  const toastMsg = document.getElementById('toastMessage');
  if (!toast) return;
  if (toastMsg) toastMsg.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}

// QR Code Modal Functions
function openQrModal() {
  const modal = document.getElementById('qrModal');
  const qrImg = document.getElementById('qrCodeImage');
  const qrUrlText = document.getElementById('qrUrlText');
  const currentUrl = window.location.href;

  if (qrUrlText) qrUrlText.textContent = currentUrl;
  if (qrImg) {
    const encoded = encodeURIComponent(currentUrl);
    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encoded}&margin=8`;
  }
  if (modal) modal.classList.add('active');
}

function closeQrModal(e) {
  const modal = document.getElementById('qrModal');
  if (modal) modal.classList.remove('active');
}

function copyLiveUrl() {
  const currentUrl = window.location.href;
  navigator.clipboard.writeText(currentUrl).then(() => {
    showToast('🔗 Website link copied to clipboard!');
  });
}

// Theme Toggle
function setupTheme() {
  const toggleBtn = document.getElementById('themeToggleBtn');
  const themeIcon = document.getElementById('themeIcon');
  const isLight = localStorage.getItem('fraud_shield_theme') === 'light';

  if (isLight) {
    document.body.classList.remove('dark-theme');
    document.body.classList.add('light-theme');
    if (themeIcon) themeIcon.textContent = '🌙';
  }

  if (toggleBtn) {
    toggleBtn.addEventListener('click', toggleTheme);
  }
}

function toggleTheme() {
  const isLight = document.body.classList.contains('light-theme');
  const themeIcon = document.getElementById('themeIcon');
  if (isLight) {
    document.body.classList.remove('light-theme');
    document.body.classList.add('dark-theme');
    localStorage.setItem('fraud_shield_theme', 'dark');
    if (themeIcon) themeIcon.textContent = '☀️';
  } else {
    document.body.classList.remove('dark-theme');
    document.body.classList.add('light-theme');
    localStorage.setItem('fraud_shield_theme', 'light');
    if (themeIcon) themeIcon.textContent = '🌙';
  }
}

// Fetch Sample Presets
async function loadSamples() {
  try {
    const res = await fetch('/api/sample-messages');
    if (res.ok) {
      const data = await res.json();
      sampleMessages = data.messages || [];
    }
  } catch (err) {
    console.error('Failed to load presets:', err);
  }
}

// Preset Handlers
function loadMessagePreset(index) {
  if (sampleMessages[index]) {
    document.getElementById('messageTextInput').value = sampleMessages[index].text;
  }
}

function loadUrlPreset(url) {
  document.getElementById('urlTextInput').value = url;
}

function loadPhonePreset(phone) {
  document.getElementById('phoneTextInput').value = phone;
}

function clearMessageInput() {
  document.getElementById('messageTextInput').value = '';
  document.getElementById('messageResultArea').style.display = 'none';
}

// Dashboard Stats & Circular Gauge
async function loadStats() {
  try {
    const res = await fetch('/api/stats');
    if (!res.ok) return;
    const stats = await res.json();

    document.getElementById('statTotalScanned').textContent = stats.total_scanned;
    document.getElementById('statHighRisk').textContent = stats.high_risk_count;
    document.getElementById('statSuspicious').textContent = stats.suspicious_count;
    document.getElementById('statSafe').textContent = stats.low_risk_count;

    // Update circular gauge
    const avgScore = stats.avg_risk_score || 0;
    const scoreElem = document.getElementById('dashRiskScore');
    scoreElem.textContent = `${Math.round(avgScore)}%`;

    const gaugeFill = document.getElementById('dashboardGaugeFill');
    // Circumference = 2 * PI * 68 ≈ 427.25
    const circumference = 427.25;
    const offset = circumference - (avgScore / 100) * circumference;
    gaugeFill.style.strokeDashoffset = offset;

    // Colorize gauge based on risk
    if (avgScore >= 65) {
      gaugeFill.style.stroke = '#ef4444';
      gaugeFill.style.filter = 'drop-shadow(0 0 10px #ef4444)';
    } else if (avgScore >= 35) {
      gaugeFill.style.stroke = '#f59e0b';
      gaugeFill.style.filter = 'drop-shadow(0 0 10px #f59e0b)';
    } else {
      gaugeFill.style.stroke = '#00f2fe';
      gaugeFill.style.filter = 'drop-shadow(0 0 10px #00f2fe)';
    }

    // Status pill
    const pill = document.getElementById('dashStatusPill');
    const text = document.getElementById('dashStatusText');
    text.textContent = stats.overall_status;

    if (stats.shield_color === 'red') {
      pill.style.background = 'rgba(239, 68, 68, 0.15)';
      pill.style.borderColor = 'rgba(239, 68, 68, 0.4)';
      pill.style.color = '#ff6b6b';
    } else if (stats.shield_color === 'orange') {
      pill.style.background = 'rgba(245, 158, 11, 0.15)';
      pill.style.borderColor = 'rgba(245, 158, 11, 0.4)';
      pill.style.color = '#fbbf24';
    } else {
      pill.style.background = 'rgba(0, 230, 118, 0.15)';
      pill.style.borderColor = 'rgba(0, 230, 118, 0.4)';
      pill.style.color = '#00e676';
    }

    // Update Threat Bar Chart & Visual Progress Indicators
    updateThreatChart(stats);
    renderLiveBars(stats);

  } catch (err) {
    console.error('Error fetching stats:', err);
  }
}

// Global Chart State
let threatBarChartInstance = null;
let currentChartView = 'severity';
let cachedStats = null;

function toggleChartView(viewType) {
  currentChartView = viewType;
  const btnSev = document.getElementById('btnChartSeverity');
  const btnCat = document.getElementById('btnChartCategory');

  if (viewType === 'severity') {
    if (btnSev) btnSev.classList.add('active');
    if (btnCat) btnCat.classList.remove('active');
  } else {
    if (btnCat) btnCat.classList.add('active');
    if (btnSev) btnSev.classList.remove('active');
  }

  if (cachedStats) {
    updateThreatChart(cachedStats);
  }
}

function updateThreatChart(stats) {
  cachedStats = stats;
  const canvas = document.getElementById('threatBarChart');
  if (!canvas || typeof Chart === 'undefined') return;

  const ctx = canvas.getContext('2d');

  let labels = [];
  let dataPoints = [];
  let bgColors = [];
  let borderColors = [];

  if (currentChartView === 'severity') {
    labels = ['🚨 High Risk Blocked', '⚠️ Suspicious Flagged', '🛡️ Low Risk Verified'];
    dataPoints = [
      Math.max(stats.high_risk_count, 1),
      Math.max(stats.suspicious_count, 1),
      Math.max(stats.low_risk_count, 1)
    ];
    bgColors = [
      'rgba(239, 68, 68, 0.75)',
      'rgba(245, 158, 11, 0.75)',
      'rgba(0, 230, 118, 0.75)'
    ];
    borderColors = ['#ef4444', '#f59e0b', '#00e676'];
  } else {
    labels = ['Banking KYC', 'Power & Utility', 'Job / Task Scam', 'Lottery Traps', 'Phishing Links', 'Wangiri Phone'];
    dataPoints = [
      Math.max(stats.high_risk_count * 2, 4),
      Math.max(stats.high_risk_count + 1, 3),
      Math.max(stats.suspicious_count + 2, 3),
      2,
      Math.max(stats.total_urls, 2),
      Math.max(stats.total_phones, 1)
    ];
    bgColors = [
      'rgba(239, 68, 68, 0.75)',
      'rgba(244, 63, 94, 0.75)',
      'rgba(245, 158, 11, 0.75)',
      'rgba(251, 191, 36, 0.75)',
      'rgba(0, 242, 254, 0.75)',
      'rgba(56, 189, 248, 0.75)'
    ];
    borderColors = ['#ef4444', '#f43f5e', '#f59e0b', '#fbbf24', '#00f2fe', '#38bdf8'];
  }

  if (threatBarChartInstance) {
    threatBarChartInstance.destroy();
  }

  threatBarChartInstance = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: currentChartView === 'severity' ? 'Threat Volume' : 'Scam Incidents',
        data: dataPoints,
        backgroundColor: bgColors,
        borderColor: borderColors,
        borderWidth: 1.5,
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(19, 28, 49, 0.95)',
          titleColor: '#00f2fe',
          bodyColor: '#ffffff',
          borderColor: 'rgba(0, 242, 254, 0.3)',
          borderWidth: 1,
          padding: 10,
          cornerRadius: 8
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: '#94a3b8',
            font: { family: "'Plus Jakarta Sans', sans-serif", size: 11, weight: '600' }
          }
        },
        y: {
          grid: { color: 'rgba(255, 255, 255, 0.05)' },
          ticks: {
            color: '#64748b',
            precision: 0,
            font: { family: "'JetBrains Mono', monospace", size: 10 }
          },
          beginAtZero: true
        }
      }
    }
  });
}

function renderLiveBars(stats) {
  const container = document.getElementById('liveThreatBarsContainer');
  if (!container) return;

  const total = Math.max(stats.total_scanned, 1);
  const highPct = Math.round((stats.high_risk_count / total) * 100);
  const suspPct = Math.round((stats.suspicious_count / total) * 100);
  const lowPct = Math.round((stats.low_risk_count / total) * 100);

  container.innerHTML = `
    <div class="live-bar-item">
      <div class="live-bar-header">
        <span>🚨 High-Risk Threat Ratio</span>
        <span style="color:#ef4444; font-family:var(--font-mono);">${highPct}% (${stats.high_risk_count})</span>
      </div>
      <div class="live-bar-track">
        <div class="live-bar-fill fill-red" style="width: ${Math.max(highPct, 12)}%;"></div>
      </div>
    </div>

    <div class="live-bar-item">
      <div class="live-bar-header">
        <span>⚠️ Suspicious Signal Ratio</span>
        <span style="color:#f59e0b; font-family:var(--font-mono);">${suspPct}% (${stats.suspicious_count})</span>
      </div>
      <div class="live-bar-track">
        <div class="live-bar-fill fill-orange" style="width: ${Math.max(suspPct, 10)}%;"></div>
      </div>
    </div>

    <div class="live-bar-item">
      <div class="live-bar-header">
        <span>🛡️ Low-Risk Verified Ratio</span>
        <span style="color:#00e676; font-family:var(--font-mono);">${lowPct}% (${stats.low_risk_count})</span>
      </div>
      <div class="live-bar-track">
        <div class="live-bar-fill fill-green" style="width: ${Math.max(lowPct, 15)}%;"></div>
      </div>
    </div>

    <div class="live-bar-item">
      <div class="live-bar-header">
        <span>⚡ AI Model Detection Accuracy</span>
        <span style="color:#00f2fe; font-family:var(--font-mono);">98.4%</span>
      </div>
      <div class="live-bar-track">
        <div class="live-bar-fill fill-cyan" style="width: 98.4%;"></div>
      </div>
    </div>
  `;
}

// Recent Activity on Dashboard
async function loadRecentActivity() {
  const container = document.getElementById('dashboardRecentList');
  try {
    const res = await fetch('/api/history?limit=4');
    if (!res.ok) return;
    const items = await res.json();

    if (items.length === 0) {
      container.innerHTML = '<div class="empty-state" style="padding:16px; color:var(--text-dim); text-align:center;">No recent scans yet. Click Scan New Message above to begin!</div>';
      return;
    }

    container.innerHTML = items.map(item => {
      let icon = '📩';
      if (item.scan_type === 'url') icon = '🔗';
      if (item.scan_type === 'phone') icon = '☎️';

      let badgeClass = 'badge-low';
      if (item.risk_level === 'HIGH RISK') badgeClass = 'badge-high';
      else if (item.risk_level === 'SUSPICIOUS') badgeClass = 'badge-suspicious';

      return `
        <div class="activity-item">
          <div class="activity-left">
            <span class="activity-icon">${icon}</span>
            <div>
              <div class="activity-content" title="${escapeHtml(item.input_content)}">${escapeHtml(item.input_content)}</div>
              <div class="activity-time">${item.scan_date}</div>
            </div>
          </div>
          <span class="badge-risk ${badgeClass}">${item.risk_level} (${Math.round(item.risk_score)}%)</span>
        </div>
      `;
    }).join('');

  } catch (err) {
    console.error('Error loading activity:', err);
  }
}

// ================= MESSAGE SCANNER =================
async function executeMessageScan() {
  const inputElem = document.getElementById('messageTextInput');
  const message = inputElem.value.trim();
  if (!message) {
    alert('Please enter or paste a message to analyze.');
    return;
  }

  const btn = document.getElementById('btnScanMessage');
  const btnText = document.getElementById('btnMessageText');
  const spinner = document.getElementById('spinnerMessage');
  const resultArea = document.getElementById('messageResultArea');

  btn.disabled = true;
  btnText.textContent = 'Analyzing with NLP...';
  spinner.style.display = 'inline-block';

  try {
    const response = await fetch('/api/scan/message', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    });

    const data = await response.json();
    renderMessageResult(data, resultArea);
    loadStats(); // update dashboard metrics
  } catch (err) {
    alert('Error connecting to AI Detection Engine: ' + err.message);
  } finally {
    btn.disabled = false;
    btnText.textContent = '🚀 Analyze Message with AI';
    spinner.style.display = 'none';
  }
}

function renderMessageResult(data, container) {
  let cardClass = 'res-low';
  let badgeClass = 'badge-low';
  if (data.risk_level === 'HIGH RISK') {
    cardClass = 'res-high';
    badgeClass = 'badge-high';
  } else if (data.risk_level === 'SUSPICIOUS') {
    cardClass = 'res-suspicious';
    badgeClass = 'badge-suspicious';
  }

  const breakdown = data.risk_breakdown || {};
  const keywordsHtml = (data.matched_keywords && data.matched_keywords.length > 0)
    ? data.matched_keywords.map(kw => `<span class="kw-pill">⚠️ ${escapeHtml(kw)}</span>`).join('')
    : '<span style="font-size:0.8rem; color:var(--text-dim);">No flagged keywords</span>';

  const reasonsHtml = data.reasons.map(r => `<li>${escapeHtml(r)}</li>`).join('');
  const recommendationsHtml = data.recommendations.map(rc => `<li>${escapeHtml(rc)}</li>`).join('');

  container.innerHTML = `
    <div class="result-card ${cardClass}">
      <div class="result-top-banner">
        <div>
          <span class="badge-risk ${badgeClass} result-badge-big">${data.risk_level}</span>
          <div style="font-size:0.75rem; color:var(--text-muted); margin-top:6px;">ML Model Confidence: ${data.model_confidence}%</div>
        </div>
        <div class="score-display-box">
          <span class="score-num">${data.risk_score}%</span>
          <span class="score-label">Fraud Probability</span>
        </div>
      </div>

      <!-- Factor Breakdown -->
      <div class="breakdown-factors-grid">
        <div class="factor-bar-item">
          <div class="factor-label-row">
            <span>Urgency Panic</span>
            <span>${breakdown.urgency_level || 0}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill ${(breakdown.urgency_level >= 60) ? 'fill-high' : ''}" style="width: ${breakdown.urgency_level || 0}%;"></div>
          </div>
        </div>

        <div class="factor-bar-item">
          <div class="factor-label-row">
            <span>Financial / KYC Solicitation</span>
            <span>${breakdown.financial_threat || 0}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill ${(breakdown.financial_threat >= 60) ? 'fill-high' : ''}" style="width: ${breakdown.financial_threat || 0}%;"></div>
          </div>
        </div>

        <div class="factor-bar-item">
          <div class="factor-label-row">
            <span>Authority Impersonation</span>
            <span>${breakdown.impersonation_threat || 0}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill ${(breakdown.impersonation_threat >= 60) ? 'fill-high' : ''}" style="width: ${breakdown.impersonation_threat || 0}%;"></div>
          </div>
        </div>

        <div class="factor-bar-item">
          <div class="factor-label-row">
            <span>Link / APK Threat</span>
            <span>${breakdown.link_threat || 0}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill ${(breakdown.link_threat >= 60) ? 'fill-high' : ''}" style="width: ${breakdown.link_threat || 0}%;"></div>
          </div>
        </div>
      </div>

      <!-- Flagged Keywords -->
      <div class="keywords-row">
        <strong style="font-size:0.8rem; margin-right:4px;">Flagged Signals:</strong>
        ${keywordsHtml}
      </div>

      <!-- Explainable Findings -->
      <div class="findings-section">
        <h4 class="findings-title">AI Fraud Assessment Reasons:</h4>
        <ul class="findings-list">
          ${reasonsHtml}
        </ul>
      </div>

      <!-- Actionable Advice -->
      <div class="recommendations-box">
        <h4>🛡️ Recommended Safety Actions:</h4>
        <ul>
          ${recommendationsHtml}
        </ul>
      </div>

      <!-- Disclaimer Banner -->
      <div class="mandatory-disclaimer-box" style="margin-top:16px;">
        <strong>Important Notice:</strong>
        <p>${escapeHtml(data.disclaimer)}</p>
      </div>
    </div>
  `;

  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ================= URL SCANNER =================
async function executeUrlScan() {
  const urlInput = document.getElementById('urlTextInput');
  const url = urlInput.value.trim();
  if (!url) {
    alert('Please enter a website link to evaluate.');
    return;
  }

  const btn = document.getElementById('btnScanUrl');
  const btnText = document.getElementById('btnUrlText');
  const spinner = document.getElementById('spinnerUrl');
  const resultArea = document.getElementById('urlResultArea');

  btn.disabled = true;
  btnText.textContent = 'Inspecting URL & Host...';
  spinner.style.display = 'inline-block';

  try {
    const res = await fetch('/api/scan/url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    const data = await res.json();
    renderUrlResult(data, resultArea);
    loadStats();
  } catch (err) {
    alert('Error during URL scan: ' + err.message);
  } finally {
    btn.disabled = false;
    btnText.textContent = '🔍 Analyze URL Safety';
    spinner.style.display = 'none';
  }
}

function renderUrlResult(data, container) {
  let cardClass = 'res-low';
  let badgeClass = 'badge-low';
  if (data.risk_level === 'HIGH RISK') {
    cardClass = 'res-high';
    badgeClass = 'badge-high';
  } else if (data.risk_level === 'SUSPICIOUS') {
    cardClass = 'res-suspicious';
    badgeClass = 'badge-suspicious';
  }

  const flagsHtml = data.flags.map(f => `<li>${escapeHtml(f)}</li>`).join('');
  const recHtml = data.recommendations.map(r => `<li>${escapeHtml(r)}</li>`).join('');

  container.innerHTML = `
    <div class="result-card ${cardClass}">
      <div class="result-top-banner">
        <div>
          <span class="badge-risk ${badgeClass} result-badge-big">${data.risk_level}</span>
          <div style="font-size:0.8rem; color:var(--text-muted); margin-top:6px; font-family:var(--font-mono);">
            Target Host: ${escapeHtml(data.hostname || 'Unknown')}
          </div>
        </div>
        <div class="score-display-box">
          <span class="score-num">${data.risk_score}%</span>
          <span class="score-label">Phishing Risk Score</span>
        </div>
      </div>

      <div class="findings-section">
        <h4 class="findings-title">URL Inspection Findings:</h4>
        <ul class="findings-list">
          ${flagsHtml}
        </ul>
      </div>

      <div class="recommendations-box">
        <h4>🛡️ Recommended Actions:</h4>
        <ul>
          ${recHtml}
        </ul>
      </div>

      <div class="mandatory-disclaimer-box" style="margin-top:16px;">
        <strong>Important Notice:</strong>
        <p>${escapeHtml(data.disclaimer)}</p>
      </div>
    </div>
  `;

  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ================= PHONE CHECKER =================
async function executePhoneScan() {
  const phoneInput = document.getElementById('phoneTextInput');
  const phone = phoneInput.value.trim();
  if (!phone) {
    alert('Please enter a phone number to check.');
    return;
  }

  const btn = document.getElementById('btnScanPhone');
  const btnText = document.getElementById('btnPhoneText');
  const spinner = document.getElementById('spinnerPhone');
  const resultArea = document.getElementById('phoneResultArea');

  btn.disabled = true;
  btnText.textContent = 'Querying Reputation Database...';
  spinner.style.display = 'inline-block';

  try {
    const res = await fetch('/api/scan/phone', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone })
    });
    const data = await res.json();
    renderPhoneResult(data, resultArea);
    loadStats();
  } catch (err) {
    alert('Error checking phone: ' + err.message);
  } finally {
    btn.disabled = false;
    btnText.textContent = '🛡️ Check Number Reputation';
    spinner.style.display = 'none';
  }
}

function renderPhoneResult(data, container) {
  let cardClass = 'res-low';
  let badgeClass = 'badge-low';
  if (data.risk_level === 'HIGH RISK') {
    cardClass = 'res-high';
    badgeClass = 'badge-high';
  } else if (data.risk_level === 'SUSPICIOUS') {
    cardClass = 'res-suspicious';
    badgeClass = 'badge-suspicious';
  }

  const flagsHtml = data.flags.map(f => `<li>${escapeHtml(f)}</li>`).join('');
  const warnHtml = data.warnings.map(w => `<li>${escapeHtml(w)}</li>`).join('');

  container.innerHTML = `
    <div class="result-card ${cardClass}">
      <div class="result-top-banner">
        <div>
          <span class="badge-risk ${badgeClass} result-badge-big">${data.risk_level}</span>
          <div style="font-size:0.8rem; color:var(--text-muted); margin-top:6px;">
            Classification: <strong>${escapeHtml(data.category)}</strong>
          </div>
        </div>
        <div class="score-display-box">
          <span class="score-num">${data.risk_score}%</span>
          <span class="score-label">Spam & Fraud Score</span>
        </div>
      </div>

      <div class="tech-specs-grid" style="margin: 14px 0;">
        <div class="tech-spec-box">
          <span class="spec-label">Registered Geographic Location</span>
          <span class="spec-value">${escapeHtml(data.location)}</span>
        </div>
        <div class="tech-spec-box">
          <span class="spec-label">Network / Carrier Routing</span>
          <span class="spec-value">${escapeHtml(data.carrier_type)}</span>
        </div>
        <div class="tech-spec-box">
          <span class="spec-label">Citizen Complaints Registered</span>
          <span class="spec-value" style="color:${data.reports_count > 0 ? '#ef4444' : '#00e676'}">${data.reports_count} Reports</span>
        </div>
      </div>

      <div class="findings-section">
        <h4 class="findings-title">Reputation Analysis:</h4>
        <ul class="findings-list">
          ${flagsHtml}
        </ul>
      </div>

      <div class="recommendations-box">
        <h4>🛡️ Advisory & Warnings:</h4>
        <ul>
          ${warnHtml}
        </ul>
      </div>

      <div class="mandatory-disclaimer-box" style="margin-top:16px;">
        <strong>Important Notice:</strong>
        <p>${escapeHtml(data.disclaimer)}</p>
      </div>
    </div>
  `;

  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ================= SCAN HISTORY =================
async function loadHistory() {
  const filter = document.getElementById('historyFilterSelect').value;
  const tbody = document.getElementById('historyTableBody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center">Loading scan history...</td></tr>';

  try {
    const url = filter === 'all' ? '/api/history' : `/api/history?type=${filter}`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:24px; color:var(--text-dim);">No scan records found in history.</td></tr>';
      return;
    }

    tbody.innerHTML = data.map(item => {
      let icon = '📩 Message';
      if (item.scan_type === 'url') icon = '🔗 URL';
      if (item.scan_type === 'phone') icon = '☎️ Phone';

      let badgeClass = 'badge-low';
      if (item.risk_level === 'HIGH RISK') badgeClass = 'badge-high';
      else if (item.risk_level === 'SUSPICIOUS') badgeClass = 'badge-suspicious';

      return `
        <tr>
          <td><strong>${icon}</strong></td>
          <td class="query-cell" title="${escapeHtml(item.input_content)}">${escapeHtml(item.input_content)}</td>
          <td><span class="badge-risk ${badgeClass}">${item.risk_level}</span></td>
          <td style="font-family:var(--font-mono); font-weight:700;">${Math.round(item.risk_score)}%</td>
          <td style="font-size:0.8rem; color:var(--text-muted);">${escapeHtml(item.summary || 'Completed')}</td>
          <td style="font-size:0.75rem; color:var(--text-dim);">${item.scan_date}</td>
          <td>
            <button class="del-btn" title="Delete record" onclick="deleteHistoryItem(${item.id})">🗑️</button>
          </td>
        </tr>
      `;
    }).join('');

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" style="color:red;">Error loading history: ${err.message}</td></tr>`;
  }
}

async function deleteHistoryItem(id) {
  if (!confirm('Are you sure you want to delete this scan record?')) return;
  try {
    const res = await fetch(`/api/history/${id}`, { method: 'DELETE' });
    if (res.ok) {
      loadHistory();
      loadStats();
    }
  } catch (err) {
    alert('Failed to delete record: ' + err.message);
  }
}

async function confirmClearHistory() {
  if (!confirm('Are you sure you want to clear ALL scan history? This action cannot be undone.')) return;
  try {
    const res = await fetch('/api/history', { method: 'DELETE' });
    if (res.ok) {
      loadHistory();
      loadStats();
      loadRecentActivity();
    }
  } catch (err) {
    alert('Failed to clear history: ' + err.message);
  }
}

// Utility: Escape HTML to prevent injection
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
