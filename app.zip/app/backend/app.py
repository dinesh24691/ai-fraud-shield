"""
AI FRAUD SHIELD - Flask REST API & Web Server
Provides full REST endpoints for SMS/Message Scanner, URL Scanner,
Phone Number Checker, Scan History, Dashboard Analytics, and serves
the interactive frontend demo interface.
"""

import os
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS

from model import detector
from url_analyzer import analyze_url
from phone_analyzer import analyze_phone_number
import database

app = Flask(__name__, static_folder="static", template_folder="templates")
CORS(app)  # Enable Cross-Origin requests for Flutter and web clients

SAMPLE_DATASETS = {
    "messages": [
        {
            "title": "Electricity Bill Threat",
            "type": "Utility Fraud",
            "text": "Dear consumer, your electricity power will be disconnected tonight at 9.30 PM from power office because your previous month bill was not updated. Please immediately contact our electricity officer at 9823412345."
        },
        {
            "title": "SBI Account KYC Expiry",
            "type": "Banking Phishing",
            "text": "Dear SBI user, your account will be blocked today due to pending KYC. Click http://sbi-kyc-verify.top to update your PAN immediately."
        },
        {
            "title": "Part-Time Task Scam",
            "type": "Job / Telegram Fraud",
            "text": "Congratulations! You are selected for part time job. Work 1 hour daily from home by rating Google maps and earn Rs 3000 to 5000 daily. Contact HR Priya on WhatsApp: http://wa.me/919988112233"
        },
        {
            "title": "Legitimate Bank Alert",
            "type": "Safe Transactional",
            "text": "Your SBI account XX4092 is credited with Rs 5,000.00 on 08-Oct-26 by transfer from John Doe. Available balance is Rs 45,210.00."
        },
        {
            "title": "Legitimate Delivery OTP",
            "type": "Safe Notification",
            "text": "Your Amazon order #402-8921829 has been dispatched and will arrive tomorrow by 8 PM. Share delivery OTP 4921 with the courier agent."
        }
    ],
    "urls": [
        {
            "title": "Fake SBI KYC Portal",
            "url": "http://sbi-kyc-verify.top/login.php"
        },
        {
            "title": "Deceptive Amazon Prize Shortener",
            "url": "https://bit.ly/amazon-gift-winner-2026"
        },
        {
            "title": "Phishing Direct IP Login",
            "url": "http://192.168.1.105/bank-security/login"
        },
        {
            "title": "Official Portal",
            "url": "https://www.onlinesbi.sbi"
        }
    ],
    "phones": [
        {
            "title": "Reported Electricity Extortionist",
            "number": "+91 98234 12345"
        },
        {
            "title": "High-Risk International Wangiri",
            "number": "+232 76123456"
        },
        {
            "title": "Reported KBC / Lottery Fraud",
            "number": "9876543210"
        },
        {
            "title": "Official SBI Toll-Free Care",
            "number": "1800112211"
        }
    ]
}


@app.route("/api/status", methods=["GET"])
def api_status():
    """System health check and engine status."""
    return jsonify({
        "status": "online",
        "app_name": "AI FRAUD SHIELD",
        "tagline": "Detect Scams. Protect Yourself.",
        "model_loaded": detector.pipeline is not None,
        "engine": "TF-IDF + Logistic Regression + Multi-Factor Heuristics",
        "version": "2.0.0"
    })


@app.route("/api/stats", methods=["GET"])
def api_stats():
    """Returns aggregated stats for the home dashboard."""
    stats = database.get_dashboard_stats()
    return jsonify(stats)


@app.route("/api/sample-messages", methods=["GET"])
def api_samples():
    """Returns preset test cases for quick expo demonstration."""
    return jsonify(SAMPLE_DATASETS)


@app.route("/api/scan/message", methods=["POST"])
def scan_message():
    """Analyzes an SMS or WhatsApp message."""
    data = request.get_json(force=True) or {}
    message_text = data.get("message", "").strip()

    if not message_text:
        return jsonify({"error": "Message text is required"}), 400

    analysis = detector.analyze_message(message_text)

    # Save to scan history
    summary_text = analysis["reasons"][0] if analysis["reasons"] else "Scanned SMS message"
    record_id = database.save_scan_record(
        scan_type="message",
        input_content=message_text,
        risk_level=analysis["risk_level"],
        risk_score=analysis["risk_score"],
        status_color=analysis["status_color"],
        summary=summary_text,
        details=analysis
    )
    analysis["id"] = record_id

    return jsonify(analysis)


@app.route("/api/scan/url", methods=["POST"])
def scan_url():
    """Analyzes a website URL."""
    data = request.get_json(force=True) or {}
    raw_url = data.get("url", "").strip()

    if not raw_url:
        return jsonify({"error": "URL string is required"}), 400

    analysis = analyze_url(raw_url)

    # Save to history
    summary_text = analysis["flags"][0] if analysis["flags"] else "Domain reputation check"
    record_id = database.save_scan_record(
        scan_type="url",
        input_content=raw_url,
        risk_level=analysis["risk_level"],
        risk_score=analysis["risk_score"],
        status_color=analysis["status_color"],
        summary=summary_text,
        details=analysis
    )
    analysis["id"] = record_id

    return jsonify(analysis)


@app.route("/api/scan/phone", methods=["POST"])
def scan_phone():
    """Analyzes a phone number."""
    data = request.get_json(force=True) or {}
    raw_phone = data.get("phone", "").strip()

    if not raw_phone:
        return jsonify({"error": "Phone number is required"}), 400

    analysis = analyze_phone_number(raw_phone)

    # Save to history
    summary_text = analysis["flags"][0] if analysis["flags"] else "Caller verification check"
    record_id = database.save_scan_record(
        scan_type="phone",
        input_content=raw_phone,
        risk_level=analysis["risk_level"],
        risk_score=analysis["risk_score"],
        status_color=analysis["status_color"],
        summary=summary_text,
        details=analysis
    )
    analysis["id"] = record_id

    return jsonify(analysis)


@app.route("/api/history", methods=["GET"])
def get_history():
    """Retrieves scan history with optional type filter."""
    scan_type = request.args.get("type")
    limit = int(request.args.get("limit", 50))
    history = database.get_all_history(scan_type=scan_type, limit=limit)
    return jsonify(history)


@app.route("/api/history/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    """Deletes an individual history item."""
    success = database.delete_history_item(item_id)
    if success:
        return jsonify({"success": True, "message": "Record deleted"})
    return jsonify({"error": "Record not found"}), 404


@app.route("/api/history", methods=["DELETE"])
def clear_history():
    """Clears all scan history."""
    count = database.clear_all_history()
    return jsonify({"success": True, "deleted_count": count})


@app.route("/")
def index():
    """Serves the interactive web app dashboard."""
    return render_template("index.html")


if __name__ == "__main__":
    # Host on 0.0.0.0 so phone on same Wi-Fi can connect during project demo
    port = int(os.environ.get("PORT", 5050))
    print(f"Starting AI Fraud Shield server on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
