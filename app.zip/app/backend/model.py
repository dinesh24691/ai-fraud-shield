"""
AI Fraud Detection Engine - Machine Learning & NLP
Combines TF-IDF Machine Learning classification with multi-factor heuristic signal extraction
to detect phishing, fraudulent SMS, and malicious social engineering messages.
Provides Explainable AI (XAI) breakdown with risk factors, matched triggers, and safety advice.
"""

import re
import os
import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from dataset import TRAINING_DATA

MODEL_FILE = os.path.join(os.path.dirname(__file__), "fraud_model.pkl")

# Heuristic & Scam Intelligence Dictionaries
URGENCY_TRIGGERS = [
    r"\bimmediat(e|ely)\b", r"\burgent(ly)?\b", r"\btonight\b", r"\bwithin 24 (hours|hrs)\b",
    r"\bwithin 2 (hours|hrs)\b", r"\bwithin 12 (hours|hrs)\b", r"\baction required\b",
    r"\bdeadline\b", r"\bwill be (blocked|suspended|deactivated|disconnected|frozen|cancelled|cut off)\b",
    r"\bpower (will be )?disconnected\b", r"\bexpire(d|s|ing)? tonight\b", r"\blast warning\b",
    r"\bfinal notice\b", r"\btoday itself\b", r"\btoday\b", r"\bhurry\b"
]

FINANCIAL_TRIGGERS = [
    r"\bkyc\b", r"\bpan card\b", r"\bpan\b", r"\baadhaar\b", r"\bdebit card\b", r"\bcredit card\b",
    r"\bcvv\b", r"\bpin\b", r"\botp\b", r"\bupi\b", r"\bbank account\b", r"\bbill\b", r"\barrears\b",
    r"\brefund\b", r"\blottery\b", r"\bcash prize\b", r"\bwon rs\b", r"\bwin \d+\b", r"\bearn rs\b",
    r"\bdaily income\b", r"\bguaranteed (return|profit)\b", r"\bcrypto\b", r"\bbitcoin\b",
    r"\btransfer fee\b", r"\bprocessing fee\b", r"\bunauthorized transaction\b"
]

IMPERSONATION_TRIGGERS = [
    r"\bsbi\b", r"\bhdfc\b", r"\bicici\b", r"\baxis bank\b", r"\bkotak\b", r"\bpnb\b",
    r"\bbescom\b", r"\bmsedcl\b", r"\belectricity (office|officer|bill|department|power)?\b",
    r"\bpower office\b", r"\bpower manager\b", r"\bpower\b", r"\bwater department\b",
    r"\bfedex\b", r"\bdhl\b", r"\bbluedart\b", r"\bindia post\b", r"\bcustoms\b",
    r"\bincome tax\b", r"\bpm kisan\b", r"\bepfo\b", r"\bministry of\b",
    r"\bdelhi police\b", r"\bmumbai police\b", r"\bcyber cell\b",
    r"\bkbc\b", r"\bjio lucky draw\b", r"\bamazon hr\b", r"\bpart time job\b"
]

ACTION_TRIGGERS = [
    r"\bclick (link|here|http)\b", r"\bdownload apk\b", r"\binstall (app|apk)\b",
    r"\bcontact (our|mr|officer|hr|manager)\b", r"\bwhatsapp\b", r"\btelegram\b",
    r"\bdial \*401\*\b", r"\bverify (your|credentials|login|account|documents)\b",
    r"\bclaim (prize|loan|gift|funds)\b", r"\bupdate (kyc|address|bill|pan)\b"
]

SUSPICIOUS_DOMAINS_RE = re.compile(
    r"https?://[^\s]+(?:\.top|\.xyz|\.click|\.work|\.cc|\.club|\.fit|\.gq|\.tk|\.ml|\.online|bit\.ly|tinyurl\.com|wa\.me|t\.me)[^\s]*",
    re.IGNORECASE
)

URL_REGEX = re.compile(r"https?://[^\s]+|www\.[^\s]+", re.IGNORECASE)


class FraudDetectionModel:
    def __init__(self):
        self.pipeline = None
        self._load_or_train()

    def _load_or_train(self):
        """Loads trained model or trains a fresh one from TRAINING_DATA."""
        if os.path.exists(MODEL_FILE):
            try:
                self.pipeline = joblib.load(MODEL_FILE)
                return
            except Exception as e:
                print(f"Notice: Reloading model due to: {e}")

        # Train new pipeline
        texts = [item[0] for item in TRAINING_DATA]
        labels = [item[1] for item in TRAINING_DATA]

        self.pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(
                ngram_range=(1, 2),
                max_features=4000,
                lowercase=True,
                stop_words='english'
            )),
            ('clf', LogisticRegression(C=2.0, max_iter=500, class_weight='balanced'))
        ])

        self.pipeline.fit(texts, labels)
        joblib.dump(self.pipeline, MODEL_FILE)
        print("Fraud Detection Model successfully trained and saved.")

    def analyze_message(self, text: str) -> dict:
        """
        Performs holistic AI analysis:
        1. NLP Machine Learning inference probability
        2. Rule-based heuristic signal extraction (Urgency, Finance, Impersonation, Action)
        3. Explainable AI breakdown with evidence and plain-English reasons
        4. Cautious risk labeling complying with expo safety guidelines
        """
        clean_text = text.strip()
        lower_text = clean_text.lower()

        # 1. ML Classifier Probability
        ml_prob = 0.10
        if self.pipeline:
            try:
                probs = self.pipeline.predict_proba([clean_text])[0]
                ml_prob = float(probs[1])  # probability of class 1 (fraud)
            except Exception as e:
                print(f"Inference error: {e}")
                ml_prob = 0.50

        # 2. Heuristic Signal Extraction
        urgency_matches = []
        for pat in URGENCY_TRIGGERS:
            found = re.findall(pat, lower_text)
            if found:
                urgency_matches.append(pat.replace(r"\b", "").replace("(", "").replace(")", "").replace("|", "/"))

        financial_matches = []
        for pat in FINANCIAL_TRIGGERS:
            found = re.findall(pat, lower_text)
            if found:
                financial_matches.append(pat.replace(r"\b", "").replace("(", "").replace(")", "").replace("|", "/"))

        impersonation_matches = []
        for pat in IMPERSONATION_TRIGGERS:
            found = re.findall(pat, lower_text)
            if found:
                impersonation_matches.append(pat.replace(r"\b", "").replace("(", "").replace(")", "").replace("|", "/"))

        action_matches = []
        for pat in ACTION_TRIGGERS:
            found = re.findall(pat, lower_text)
            if found:
                action_matches.append(pat.replace(r"\b", "").replace("(", "").replace(")", "").replace("|", "/"))

        urls_found = URL_REGEX.findall(clean_text)
        suspicious_urls_found = SUSPICIOUS_DOMAINS_RE.findall(clean_text)
        has_apk = bool(re.search(r"\bapk\b", lower_text))
        has_phone_number = bool(re.search(r"\b(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b|\b\d{10}\b", clean_text))

        # Calculate Sub-factor Risk Scores (0 to 100)
        urgency_score = min(100, len(urgency_matches) * 35)
        financial_score = min(100, len(financial_matches) * 30)
        impersonation_score = min(100, len(impersonation_matches) * 40)
        link_score = 100 if suspicious_urls_found else (60 if urls_found else 0)
        if has_apk:
            link_score = max(link_score, 95)

        # 3. Blended Composite Score
        heuristic_score = (
            (urgency_score * 0.25) +
            (financial_score * 0.25) +
            (impersonation_score * 0.25) +
            (link_score * 0.25)
        )

        # Composite blending: 55% ML Model + 45% Heuristics
        ml_score_100 = ml_prob * 100
        final_score = (ml_score_100 * 0.55) + (heuristic_score * 0.45)

        # Critical Overrides: If strong phishing link + urgent threat exists, ensure High Risk
        if (suspicious_urls_found or has_apk) and (urgency_matches or financial_matches):
            final_score = max(final_score, 88.0)
        elif len(urgency_matches) >= 2 and len(impersonation_matches) >= 1:
            final_score = max(final_score, 82.0)

        final_score = float(np.clip(final_score, 4.0, 99.0))
        final_score_rounded = round(final_score, 1)

        # 4. Risk Classification with Nuanced Expo Disclaimer
        if final_score_rounded >= 70.0:
            risk_level = "HIGH RISK"
            status_color = "red"
        elif final_score_rounded >= 35.0:
            risk_level = "SUSPICIOUS"
            status_color = "orange"
        else:
            # Important requirement: Not claiming guaranteed safe solely because no indicators triggered
            risk_level = "LOW RISK"
            status_color = "green"

        # 5. Explainable AI (XAI) Reasons
        reasons = []
        matched_keywords = []

        if urgency_matches:
            reasons.append("Artificial Urgency: Creates panic or imposes an immediate deadline to rush decision-making.")
            matched_keywords.extend([m.strip() for m in urgency_matches[:3]])

        if financial_matches:
            reasons.append("Financial / Credential Request: Mentions bank accounts, KYC updates, funds, or card data.")
            matched_keywords.extend([m.strip() for m in financial_matches[:3]])

        if impersonation_matches:
            reasons.append("Brand / Authority Impersonation: Mimics legitimate institutions (banks, utility boards, or government).")
            matched_keywords.extend([m.strip() for m in impersonation_matches[:3]])

        if suspicious_urls_found:
            reasons.append("Suspicious / Unverified Link: Contains external links hosted on unverified or high-risk domains.")
            matched_keywords.append("unverified link")
        elif urls_found:
            reasons.append("External Link Attached: Contains link(s) redirecting outside the messaging app.")

        if has_apk:
            reasons.append("Malicious File Download: Prompts downloading an Android APK package directly.")
            matched_keywords.append("apk")

        if action_matches and (financial_matches or urgency_matches):
            reasons.append("Unprompted Call to Action: Instructs you to contact third-party Telegram or WhatsApp handlers.")

        if not reasons:
            reasons.append("No prominent fraud patterns detected in vocabulary or message structure.")

        # 6. Safety Recommendations
        recommendations = []
        if risk_level == "HIGH RISK":
            recommendations.append("Do NOT click any links, dial the provided numbers, or reply to this message.")
            recommendations.append("Do NOT share OTPs, passwords, PINs, or UPI credentials under any circumstances.")
            recommendations.append("Report suspected cyber fraud immediately to National Cyber Crime portal (1930 or cybercrime.gov.in).")
        elif risk_level == "SUSPICIOUS":
            recommendations.append("Verify directly through official apps or customer care numbers on legitimate statements.")
            recommendations.append("Check the sender ID carefully. Banks and official bodies never use standard 10-digit mobile numbers.")
        else:
            recommendations.append("Always exercise caution with unsolicited messages even when no high risk triggers are flagged.")
            recommendations.append("Avoid clicking external links or downloading attachments from unverified senders.")

        return {
            "risk_level": risk_level,
            "risk_score": final_score_rounded,
            "status_color": status_color,
            "model_confidence": round(ml_prob * 100, 1),
            "reasons": reasons,
            "matched_keywords": list(set(matched_keywords)),
            "risk_breakdown": {
                "urgency_level": urgency_score,
                "financial_threat": financial_score,
                "impersonation_threat": impersonation_score,
                "link_threat": link_score
            },
            "recommendations": recommendations,
            "disclaimer": "AI predictions are not guarantees. The app should not label a message or website safe solely because no suspicious indicators were detected."
        }


# Singleton model instance
detector = FraudDetectionModel()

if __name__ == "__main__":
    test_msg = "Dear consumer, your electricity power will be disconnected tonight at 9.30 PM from power office. Call officer at 9823412345."
    res = detector.analyze_message(test_msg)
    print("Test Result:", res)
