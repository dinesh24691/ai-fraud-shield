# 🛡️ AI FRAUD SHIELD
> **Detect Scams. Protect Yourself.**  
> *A cutting-edge Cyber Scam & Phishing Detection App for Android, built with Flutter, Python & Machine Learning for College Project Expo.*

---

## 🚀 Quick Start (Instant Expo Demo)

### 1. Launch the Backend Server & Dashboard (1-Click)
Double-click `run_backend.bat` or run:
```powershell
python backend/app.py
```
The server will start on **`http://localhost:5050`**.

### 2. Open the Live Interactive Dashboard
Double-click `open_dashboard.bat` or open:
👉 **[http://localhost:5050](http://localhost:5050)** in any web browser.

You will see the **dark navy dashboard with glowing cyan & green accents**, the animated threat meter gauge, preset demo buttons, and live AI scans!

### 3. Run the Flutter Android App
When ready on your Android device or emulator:
```powershell
cd flutter_app
flutter run
```
*(The Flutter app includes automatic fallback heuristics, so your presentation runs flawlessly even without internet access!)*

---

## 🌟 Key Features

| Feature | Description |
|---|---|
| 🏠 **Home Dashboard** | Dark navy theme, circular AI risk gauge, telemetry stats, live advisories |
| 📩 **SMS & Message Scanner** | Real-time NLP analysis, XAI causal reasons, risk factor progress bars |
| 🔗 **URL Scanner** | Flags typosquatting, suspicious TLDs (`.top`, `.xyz`), IP hosts, shorteners |
| ☎️ **Phone Checker** | Queries community cybercrime blacklist, Wangiri toll scams, VoIP detection |
| 🤖 **AI Detection Engine** | TF-IDF (4000+ n-grams) + Logistic Regression + Heuristic safety bounds |
| 📊 **Scan History** | Persistent SQLite storage (`fraud_shield.db`), filtering, single & bulk deletion |
| ⚙️ **Settings** | Dark/Light theme toggle, privacy mode, API server config, and safety disclaimer |

---

## 📁 Project Directory Structure

```text
app/
├── backend/
│   ├── app.py                # Flask REST API Server (port 5050)
│   ├── dataset.py            # Scam & Legitimate SMS dataset
│   ├── model.py              # Machine Learning NLP & XAI engine
│   ├── url_analyzer.py       # Phishing URL & domain scanner
│   ├── phone_analyzer.py     # Phone reputation & blacklist checker
│   ├── database.py           # SQLite database persistence layer
│   ├── templates/index.html  # Dark navy interactive web dashboard
│   └── static/               # CSS styles & JS frontend logic
│
├── flutter_app/              # Complete Flutter Android Codebase
│   ├── pubspec.yaml          # Flutter dependencies
│   ├── android/              # AndroidManifest with Internet permissions
│   └── lib/
│       ├── main.dart         # Flutter entry point
│       ├── theme/            # AppTheme (Dark Navy & Glowing Accents)
│       ├── models/           # Data models (Message, URL, Phone, Stats)
│       ├── services/         # ApiService (HTTP client + offline backup)
│       ├── providers/        # AppState state management
│       ├── widgets/          # RiskGauge, GlassCard, ShieldHeader
│       └── screens/          # Dashboard, SMS, URL, Phone, History, Settings
│
├── docs/
│   └── PROJECT_REPORT.md     # Full Project Report & Viva Examination Q&A
│
├── run_backend.bat           # 1-click script to run backend
├── open_dashboard.bat         # 1-click script to launch browser dashboard
├── run_flutter.bat           # 1-click script to run Flutter app
└── README.md
```

---

## 🎓 College Project Expo Viva Notes
Review [`docs/PROJECT_REPORT.md`](file:///c:/Users/N%20Meghana/OneDrive/Desktop/app/docs/PROJECT_REPORT.md) for detailed examiner questions and answers regarding TF-IDF feature weighting, the hybrid heuristic architecture, and why cautious labeling is an ethical cybersecurity standard.
